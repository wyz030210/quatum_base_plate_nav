#!/usr/bin/env python3
"""Rasterize the fixed collision boxes in room3.world into the Nav2 map."""

import math
from pathlib import Path
import xml.etree.ElementTree as ET


RESOLUTION = 0.05
WIDTH = 596
HEIGHT = 114
ORIGIN_X = -1.39
ORIGIN_Y = -3.31
WORLD_TO_MAP_X = 13.5
WORLD_TO_MAP_Y = -0.5
FREE = 254
UNKNOWN = 205
OCCUPIED = 0


def _pose(element):
    if element is None or not element.text:
        return 0.0, 0.0, 0.0
    values = [float(value) for value in element.text.split()]
    return values[0], values[1], values[5]


def _compose(parent, child):
    px, py, pyaw = parent
    cx, cy, cyaw = child
    return (
        px + math.cos(pyaw) * cx - math.sin(pyaw) * cy,
        py + math.sin(pyaw) * cx + math.cos(pyaw) * cy,
        pyaw + cyaw,
    )


def _map_cell_center(row, column):
    map_x = ORIGIN_X + (column + 0.5) * RESOLUTION
    map_y = ORIGIN_Y + (HEIGHT - row - 0.5) * RESOLUTION
    return map_x - WORLD_TO_MAP_X, map_y - WORLD_TO_MAP_Y


def _paint_box(pixels, pose, size):
    center_x, center_y, yaw = pose
    half_x = size[0] / 2.0 + RESOLUTION / 2.0
    half_y = size[1] / 2.0 + RESOLUTION / 2.0
    radius = math.hypot(half_x, half_y)
    minimum_map_x = center_x + WORLD_TO_MAP_X - radius
    maximum_map_x = center_x + WORLD_TO_MAP_X + radius
    minimum_map_y = center_y + WORLD_TO_MAP_Y - radius
    maximum_map_y = center_y + WORLD_TO_MAP_Y + radius
    minimum_column = max(0, math.floor((minimum_map_x - ORIGIN_X) / RESOLUTION))
    maximum_column = min(
        WIDTH - 1, math.ceil((maximum_map_x - ORIGIN_X) / RESOLUTION)
    )
    minimum_row_from_bottom = max(
        0, math.floor((minimum_map_y - ORIGIN_Y) / RESOLUTION)
    )
    maximum_row_from_bottom = min(
        HEIGHT - 1, math.ceil((maximum_map_y - ORIGIN_Y) / RESOLUTION)
    )
    cosine = math.cos(yaw)
    sine = math.sin(yaw)
    for row_from_bottom in range(minimum_row_from_bottom, maximum_row_from_bottom + 1):
        row = HEIGHT - 1 - row_from_bottom
        for column in range(minimum_column, maximum_column + 1):
            world_x, world_y = _map_cell_center(row, column)
            delta_x = world_x - center_x
            delta_y = world_y - center_y
            local_x = cosine * delta_x + sine * delta_y
            local_y = -sine * delta_x + cosine * delta_y
            if abs(local_x) <= half_x and abs(local_y) <= half_y:
                pixels[row * WIDTH + column] = OCCUPIED


def generate(world_path, target_path):
    pixels = bytearray([UNKNOWN] * (WIDTH * HEIGHT))
    # The outer collision walls span world x=[-15, 15], y=[-2.5, 2.5].
    # Mark the room interior free first; collision geometry is painted next.
    for row in range(HEIGHT):
        for column in range(WIDTH):
            world_x, world_y = _map_cell_center(row, column)
            if -15.0 <= world_x <= 15.0 and -2.5 <= world_y <= 2.5:
                pixels[row * WIDTH + column] = FREE

    root = ET.parse(world_path).getroot()
    for model in root.findall("./world/model"):
        if model.attrib.get("name") == "ground_plane":
            continue
        model_pose = _pose(model.find("pose"))
        for link in model.findall("link"):
            link_pose = _compose(model_pose, _pose(link.find("pose")))
            for collision in link.findall("collision"):
                size_element = collision.find("./geometry/box/size")
                if size_element is None:
                    continue
                collision_pose = _compose(link_pose, _pose(collision.find("pose")))
                size = [float(value) for value in size_element.text.split()]
                _paint_box(pixels, collision_pose, size)

    target_path.write_bytes(
        f"P5\n{WIDTH} {HEIGHT}\n255\n".encode("ascii") + bytes(pixels)
    )


if __name__ == "__main__":
    package_root = Path(__file__).resolve().parents[1]
    workspace_src = package_root.parent
    generate(
        package_root / "worlds" / "room3.world",
        workspace_src
        / "turtlebot3-humble"
        / "turtlebot3_navigation2"
        / "map"
        / "map.pgm",
    )
