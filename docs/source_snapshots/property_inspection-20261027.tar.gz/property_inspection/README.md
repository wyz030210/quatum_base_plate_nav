# Property Inspection 与全覆盖规划

该包在 TurtleBot3 Gazebo 仿真中执行 YAML 配置的逐点巡检任务。Nav2 行为树负责导航恢复；任务管理器只处理最终导航结果、模拟到点动作和报告。

该包还提供独立的 OpenNav Coverage 全覆盖任务。覆盖任务复用现有 Gazebo、AMCL 和 Nav2，使用单独的 RPP 控制器，不改变逐点巡检使用的 DWB 控制器。

## 构建

```bash
source /opt/ros/humble/setup.bash
colcon build --packages-select turtlebot3_navigation2 property_inspection
source install/setup.bash
```

同时构建 `turtlebot3_navigation2` 可确保默认长地图安装到当前工作空间。

首次包含覆盖依赖的完整构建建议使用：

```bash
source /opt/ros/humble/setup.bash
colcon build --packages-up-to property_inspection --symlink-install \
  --cmake-args -DUSE_ORTOOLS_VENDOR=ON -DBUILD_PYTHON=OFF \
  -DBUILD_TUTORIALS=OFF
source install/setup.bash
```

## 全覆盖任务

一条命令启动 Burger、`room3.world`、Nav2、Coverage Server、任务节点和扩展 RViz：

```bash
ros2 launch property_inspection coverage_sim.launch.py
```

启动后按以下顺序操作：

1. 在 RViz 中用 `2D Pose Estimate` 设置初始位姿，并等待 AMCL 收敛。
2. 选择 `Publish Point`，按顺序点击外边界各顶点。边界必须自行避开墙体的膨胀区。
3. 在新终端（已 source 工作区）闭合外边界：

   ```bash
   ros2 run property_inspection coverage_cli close-outer
   ```

4. 如需标记内部障碍，开始孔洞、在 RViz 点击孔洞顶点并闭合：

   ```bash
   ros2 run property_inspection coverage_cli begin-hole
   ros2 run property_inspection coverage_cli close-hole
   ```

5. 手动启动覆盖任务：

   ```bash
   ros2 run property_inspection coverage_cli start
   ```

默认虚拟作业宽度是 `0.5 m`，条带方向自动优化。可在启动时覆盖：

```bash
ros2 run property_inspection coverage_cli start \
  --operation-width 0.5 --swath-angle-deg 90
```

`--swath-angle-deg auto` 恢复自动优化。任务执行中可查询或取消：

```bash
ros2 run property_inspection coverage_cli status
ros2 run property_inspection coverage_cli cancel
```

编辑辅助命令还有 `undo-point` 和 `clear`。覆盖报告写入
`~/.ros/property_inspection/reports/coverage/`，包含规划/实际路程、耗时、路径完成率、轨迹估算面积覆盖率与失败原因。碰撞状态固定记录为 `not_instrumented`，必须在 Gazebo/RViz 中人工观察。

## 正常任务

```bash
ros2 launch property_inspection inspection_sim.launch.py \
  mission_id:=night_patrol gui:=true rviz:=true
```

默认仿真环境使用本包安装的 `worlds/room3.world`，并搭配
`turtlebot3_navigation2/map/map.yaml` 长地图。默认任务依次执行位于该长地图上的
门岗、楼栋入口、消防箱、配电箱、垃圾桶和回充点六个点位。

该长地图由 `scripts/generate_room3_map.py` 根据 `room3.world` 的固定碰撞几何生成，
世界坐标到地图坐标的平移为 `(13.5, -0.5)`。修改房间墙体或固定方块后，应重新运行：

```bash
python3 src/property_inspection/scripts/generate_room3_map.py
colcon build --packages-select turtlebot3_navigation2 property_inspection
```

Gazebo 中的模型出生坐标与 Nav2 地图中的初始位姿坐标是两组独立参数：
`spawn_x`/`spawn_y`/`spawn_yaw` 设置 Gazebo world 坐标系中的出生位姿，
`initial_pose_x`/`initial_pose_y`/`initial_pose_yaw` 设置 Nav2 map 坐标系中的初始位姿。
更换 world 或 map 时应分别按它们的坐标系同时覆盖两组位姿，例如：

```bash
ros2 launch property_inspection inspection_sim.launch.py \
  mission_id:=night_patrol gui:=true rviz:=true \
  world:=/absolute/path/to/custom.world \
  map:=/absolute/path/to/custom_map.yaml \
  spawn_x:=-10.5 spawn_y:=-1.0 spawn_yaw:=0.0 \
  initial_pose_x:=3.0 initial_pose_y:=-1.5 initial_pose_yaw:=0.0
```

使用自定义 world/map 时，还必须同步修改
`src/property_inspection/config/inspection_points.yaml` 中的巡检点位坐标，并重新执行上述构建命令。
当前 launch 不提供运行时点位配置路径参数；如果只覆盖 world/map 而不修改该文件，
任务仍会在新地图上使用默认六个点位坐标。

## 失败跳过演示

```bash
ros2 launch property_inspection inspection_sim.launch.py \
  mission_id:=blocked_optional_demo gui:=false rviz:=false
```

测试任务包含地图外的可跳过点。Nav2 完成局部清图、等待、后退和旋转恢复后返回最终失败；任务管理器记录 `SKIPPED` 并继续。

## 配置与报告

- `config/inspection_points.yaml`：点位坐标、类型、停留时间和 `allow_skip`。
- `config/mission_templates.yaml`：任务点位顺序和 Nav2 BT 文件。
- `behavior_trees/inspection_nav_to_pose.xml`：项目专用恢复流程。
- 报告默认位于 `~/.ros/property_inspection/reports/mission_<UTC>_<mission_id>/`。

每次任务生成 `point_records.jsonl`、`summary.json` 和 `summary.csv`。阶段 1 不采集 `/odom`，不统计路径长度，也不在任务层清图或重试。

## 测试

```bash
colcon test --packages-select property_inspection
colcon test-result --verbose
```
