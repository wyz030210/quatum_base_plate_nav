"""Small adapter around Nav2 Simple Commander."""

from __future__ import annotations

import math
import signal
import time
import uuid
from typing import Callable, Protocol

import rclpy
from action_msgs.srv import CancelGoal
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from nav2_msgs.srv import ManageLifecycleNodes
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
from unique_identifier_msgs.msg import UUID

from .models import NavigationResult, Pose2D


class Navigator(Protocol):
    """Port consumed by the mission runner."""

    def navigate_to(self, pose: Pose2D, behavior_tree: str) -> NavigationResult:
        """Navigate once and return Nav2's final outcome."""


class BasicNavigatorAdapter:
    """Translate domain poses and outcomes without implementing recovery."""

    def __init__(
        self,
        navigator: BasicNavigator,
        navigation_timeout_sec: float = 120.0,
        activation_timeout_sec: float = 120.0,
        cancel_timeout_sec: float = 5.0,
        poll_interval_sec: float = 0.1,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
        spin_until_future_complete: Callable = rclpy.spin_until_future_complete,
    ) -> None:
        if not math.isfinite(navigation_timeout_sec) or navigation_timeout_sec <= 0:
            raise ValueError('navigation_timeout_sec must be positive')
        if not math.isfinite(poll_interval_sec) or poll_interval_sec <= 0:
            raise ValueError('poll_interval_sec must be positive')
        if not math.isfinite(activation_timeout_sec) or activation_timeout_sec <= 0:
            raise ValueError('activation_timeout_sec must be positive')
        if not math.isfinite(cancel_timeout_sec) or cancel_timeout_sec <= 0:
            raise ValueError('cancel_timeout_sec must be positive')
        self._navigator = navigator
        self._timeout = navigation_timeout_sec
        self._activation_timeout = activation_timeout_sec
        self._cancel_timeout = cancel_timeout_sec
        self._poll_interval = poll_interval_sec
        self._monotonic = monotonic
        self._sleep = sleep
        self._spin_until_future_complete = spin_until_future_complete
        self._pending_send_future = None
        self._pending_goal_uuid = None
        self._cancel_goal_client = None
        self._lifecycle_client = None

    def _pose_stamped(self, pose: Pose2D) -> PoseStamped:
        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.header.stamp = self._navigator.get_clock().now().to_msg()
        goal.pose.position.x = pose.x
        goal.pose.position.y = pose.y
        goal.pose.orientation.z = math.sin(pose.yaw / 2.0)
        goal.pose.orientation.w = math.cos(pose.yaw / 2.0)
        return goal

    def set_initial_pose(self, pose: Pose2D) -> None:
        self._navigator.setInitialPose(self._pose_stamped(pose))

    def wait_until_active(self) -> None:
        previous_handler = signal.getsignal(signal.SIGALRM)

        def activation_timeout(_signum, _frame):
            raise TimeoutError(
                'Nav2 activation exceeded '
                f'{self._activation_timeout:.3f} seconds'
            )

        signal.signal(signal.SIGALRM, activation_timeout)
        previous_timer = signal.setitimer(
            signal.ITIMER_REAL, self._activation_timeout
        )
        try:
            self._navigator.waitUntilNav2Active()
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0.0)
            signal.signal(signal.SIGALRM, previous_handler)
            if previous_timer[0] > 0.0:
                signal.setitimer(
                    signal.ITIMER_REAL,
                    previous_timer[0],
                    previous_timer[1],
                )

    def navigate_to(self, pose: Pose2D, behavior_tree: str) -> NavigationResult:
        if self._pending_send_future is not None:
            raise RuntimeError('previous NavigateToPose goal response is unresolved')
        self._navigator.goal_handle = None
        self._navigator.result_future = None

        deadline = self._monotonic() + self._timeout
        action_client = self._navigator.nav_to_pose_client
        while True:
            remaining = deadline - self._monotonic()
            if remaining <= 0.0:
                raise TimeoutError('NavigateToPose action server unavailable')
            if action_client.wait_for_server(timeout_sec=min(1.0, remaining)):
                break

        goal = NavigateToPose.Goal()
        goal.pose = self._pose_stamped(pose)
        goal.behavior_tree = behavior_tree
        goal_uuid = UUID()
        goal_uuid.uuid = list(uuid.uuid4().bytes)
        send_future = action_client.send_goal_async(goal, goal_uuid=goal_uuid)
        self._pending_send_future = send_future
        self._pending_goal_uuid = goal_uuid
        if not send_future.done():
            remaining = deadline - self._monotonic()
            if remaining <= 0.0:
                raise TimeoutError('NavigateToPose goal response timed out')
            self._spin_until_future_complete(
                self._navigator,
                send_future,
                timeout_sec=remaining,
            )
        if not send_future.done():
            raise TimeoutError('NavigateToPose goal response timed out')

        self._pending_send_future = None
        self._pending_goal_uuid = None
        goal_handle = send_future.result()
        if goal_handle is None or not goal_handle.accepted:
            return NavigationResult.FAILED
        self._navigator.goal_handle = goal_handle
        self._navigator.result_future = goal_handle.get_result_async()

        while not self._navigator.isTaskComplete():
            if self._monotonic() >= deadline:
                if not self.cancel():
                    raise TimeoutError(
                        'Nav2 goal cancel did not complete within '
                        f'{self._cancel_timeout:.3f} seconds'
                    )
                return NavigationResult.TIMEOUT
            self._sleep(self._poll_interval)

        return {
            TaskResult.SUCCEEDED: NavigationResult.SUCCESS,
            TaskResult.FAILED: NavigationResult.FAILED,
            TaskResult.CANCELED: NavigationResult.CANCELED,
        }.get(self._navigator.getResult(), NavigationResult.FAILED)

    def cancel(self) -> bool:
        pending_send_future = self._pending_send_future
        if pending_send_future is not None:
            if not pending_send_future.done():
                self._spin_until_future_complete(
                    self._navigator,
                    pending_send_future,
                    timeout_sec=self._cancel_timeout,
                )
            if pending_send_future.done():
                self._pending_send_future = None
                self._pending_goal_uuid = None
                try:
                    goal_handle = pending_send_future.result()
                except Exception:  # noqa: B902 - cancellation is best effort
                    return self._pause_navigation()
                if goal_handle is None or not goal_handle.accepted:
                    return True
                self._navigator.goal_handle = goal_handle
                self._navigator.result_future = goal_handle.get_result_async()
            else:
                return self._cancel_pending_goal()

        goal_handle = getattr(self._navigator, 'goal_handle', None)
        result_future = getattr(self._navigator, 'result_future', None)
        if goal_handle is None or result_future is None:
            return True

        return self._cancel_goal_handle(goal_handle)

    def _cancel_goal_handle(self, goal_handle) -> bool:
        cancel_future = goal_handle.cancel_goal_async()
        if not cancel_future.done():
            self._spin_until_future_complete(
                self._navigator,
                cancel_future,
                timeout_sec=self._cancel_timeout,
            )
        if not cancel_future.done():
            return False

        deadline = self._monotonic() + self._cancel_timeout
        while not self._navigator.isTaskComplete():
            if self._monotonic() >= deadline:
                return False
            self._sleep(self._poll_interval)
        return True

    def _cancel_pending_goal(self) -> bool:
        if self._pending_goal_uuid is None:
            return self._pause_navigation()
        if self._cancel_goal_client is None:
            self._cancel_goal_client = self._navigator.create_client(
                CancelGoal,
                '/navigate_to_pose/_action/cancel_goal',
            )
        if not self._cancel_goal_client.wait_for_service(
            timeout_sec=self._cancel_timeout
        ):
            return self._pause_navigation()

        request = CancelGoal.Request()
        request.goal_info.goal_id = self._pending_goal_uuid
        cancel_future = self._cancel_goal_client.call_async(request)
        if not cancel_future.done():
            self._spin_until_future_complete(
                self._navigator,
                cancel_future,
                timeout_sec=self._cancel_timeout,
            )
        if not cancel_future.done():
            return self._pause_navigation()

        if self._pending_send_future.done():
            pending_send_future = self._pending_send_future
            self._pending_send_future = None
            self._pending_goal_uuid = None
            goal_handle = pending_send_future.result()
            if goal_handle is None or not goal_handle.accepted:
                return True
            self._navigator.goal_handle = goal_handle
            self._navigator.result_future = goal_handle.get_result_async()
            return self._cancel_goal_handle(goal_handle)

        response = cancel_future.result()
        if response is None:
            return self._pause_navigation()
        if response.return_code == CancelGoal.Response.ERROR_GOAL_TERMINATED:
            self._pending_send_future = None
            self._pending_goal_uuid = None
            return True

        # ERROR_UNKNOWN_GOAL_ID may mean the cancel arrived before the goal.
        # ERROR_NONE only confirms transition to CANCELING, not termination.
        # Pausing Nav2 prevents a late goal request from driving the robot.
        return self._pause_navigation()

    def _pause_navigation(self) -> bool:
        if self._lifecycle_client is None:
            self._lifecycle_client = self._navigator.create_client(
                ManageLifecycleNodes,
                '/lifecycle_manager_navigation/manage_nodes',
            )
        if not self._lifecycle_client.wait_for_service(
            timeout_sec=self._cancel_timeout
        ):
            return False

        request = ManageLifecycleNodes.Request()
        request.command = ManageLifecycleNodes.Request.PAUSE
        pause_future = self._lifecycle_client.call_async(request)
        if not pause_future.done():
            self._spin_until_future_complete(
                self._navigator,
                pause_future,
                timeout_sec=self._cancel_timeout,
            )
        if not pause_future.done():
            return False

        response = pause_future.result()
        if response is None or not response.success:
            return False
        self._pending_send_future = None
        self._pending_goal_uuid = None
        self._navigator.goal_handle = None
        self._navigator.result_future = None
        return True
