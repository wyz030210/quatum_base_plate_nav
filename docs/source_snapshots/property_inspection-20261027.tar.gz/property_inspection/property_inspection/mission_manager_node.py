"""One-shot ROS entry point for a configured inspection mission."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import signal

import rclpy
from ament_index_python.packages import get_package_share_directory
from nav2_simple_commander.robot_navigator import BasicNavigator
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.signals import SignalHandlerOptions

from .config_loader import InspectionConfig, load_configuration
from .inspection_executor import SimulatedInspectionExecutor
from .mission_reporter import MissionReporter
from .mission_runner import MissionRunResult, MissionRunner
from .models import MissionState, Pose2D
from .navigator import BasicNavigatorAdapter


@dataclass(frozen=True)
class RuntimePaths:
    points: Path
    missions: Path
    behavior_trees: Path


def runtime_paths(package_share: Path | str) -> RuntimePaths:
    share = Path(package_share)
    return RuntimePaths(
        points=share / 'config/inspection_points.yaml',
        missions=share / 'config/mission_templates.yaml',
        behavior_trees=share / 'behavior_trees',
    )


def execute_loaded_mission(
    config: InspectionConfig,
    mission_id: str,
    navigator,
    inspector,
    reporter,
    initial_pose: Pose2D,
    state_callback=None,
) -> MissionRunResult:
    mission = config.get_mission(mission_id)
    navigator.set_initial_pose(initial_pose)
    navigator.wait_until_active()
    return MissionRunner(
        navigator,
        inspector,
        reporter,
        state_callback=state_callback,
    ).run(mission, config.points)


def abort_active_mission(navigator, reporter, message: str) -> None:
    """Best-effort cancellation and durable ABORTED report finalization."""
    if navigator is not None:
        try:
            navigator.cancel()
        except Exception:
            pass
    if reporter is not None and reporter.run_dir is not None:
        try:
            reporter.finalize(MissionState.ABORTED, message)
        except Exception:
            pass


def _raise_keyboard_interrupt(_signum, _frame) -> None:
    raise KeyboardInterrupt


def initialize_rclpy(args=None) -> None:
    rclpy.init(args=args, signal_handler_options=SignalHandlerOptions.NO)
    signal.signal(signal.SIGINT, _raise_keyboard_interrupt)
    signal.signal(signal.SIGTERM, _raise_keyboard_interrupt)


def _declare_runtime_parameters(node: Node) -> None:
    node.declare_parameter('mission_id', 'night_patrol')
    node.declare_parameter('report_dir', '~/.ros/property_inspection/reports')
    node.declare_parameter('navigation_timeout_sec', 120.0)
    node.declare_parameter('initial_pose_x', -2.0)
    node.declare_parameter('initial_pose_y', -0.5)
    node.declare_parameter('initial_pose_yaw', 0.0)
    node.declare_parameter('points_file', '')
    node.declare_parameter('missions_file', '')


def main(args=None) -> int:
    initialize_rclpy(args)
    node = Node('mission_manager')
    _declare_runtime_parameters(node)
    basic_navigator = None
    reporter = None
    adapter = None
    try:
        share = Path(get_package_share_directory('property_inspection'))
        paths = runtime_paths(share)

        # Allow overriding YAML paths via parameters
        custom_points = node.get_parameter('points_file').value
        custom_missions = node.get_parameter('missions_file').value
        if custom_points:
            paths = RuntimePaths(
                points=Path(custom_points),
                missions=paths.missions,
                behavior_trees=paths.behavior_trees,
            )
        if custom_missions:
            paths = RuntimePaths(
                points=paths.points,
                missions=Path(custom_missions),
                behavior_trees=paths.behavior_trees,
            )

        config = load_configuration(paths.points, paths.missions, paths.behavior_trees)

        mission_id = node.get_parameter('mission_id').value
        use_sim_time = bool(node.get_parameter('use_sim_time').value)
        basic_navigator = BasicNavigator(node_name='inspection_navigator')
        basic_navigator.set_parameters([
            Parameter('use_sim_time', Parameter.Type.BOOL, use_sim_time)
        ])
        adapter = BasicNavigatorAdapter(
            basic_navigator,
            navigation_timeout_sec=float(
                node.get_parameter('navigation_timeout_sec').value
            ),
        )
        reporter = MissionReporter(node.get_parameter('report_dir').value)
        initial_pose = Pose2D(
            float(node.get_parameter('initial_pose_x').value),
            float(node.get_parameter('initial_pose_y').value),
            float(node.get_parameter('initial_pose_yaw').value),
        )

        def log_state(state: MissionState) -> None:
            node.get_logger().info('Mission state: %s' % state.value)

        result = execute_loaded_mission(
            config,
            mission_id,
            adapter,
            SimulatedInspectionExecutor(),
            reporter,
            initial_pose,
            state_callback=log_state,
        )
        node.get_logger().info('Mission report: %s' % result.report_path)
        return 0 if result.state is MissionState.FINISHED else 1
    except KeyboardInterrupt:
        abort_active_mission(adapter, reporter, 'Interrupted by user')
        return 1
    except Exception as exc:  # ROS entry point must produce a clear terminal error.
        abort_active_mission(adapter, reporter, str(exc))
        node.get_logger().error('Mission failed to start or execute: %s' % exc)
        return 1
    finally:
        if basic_navigator is not None:
            basic_navigator.destroyNode()
        node.destroy_node()
        rclpy.try_shutdown()
