"""Immutable domain models shared by the inspection mission components."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PointType(str, Enum):
    SECURITY = "security"
    FACILITY = "facility"
    ENVIRONMENT = "environment"
    DOCK = "dock"


class MissionState(str, Enum):
    IDLE = "idle"
    LOAD_MISSION = "load_mission"
    NAVIGATING = "navigating"
    INSPECTING = "inspecting"
    LOGGING = "logging"
    FINISHED = "finished"
    ABORTED = "aborted"


class NavigationResult(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    CANCELED = "canceled"
    TIMEOUT = "timeout"


class PointStatus(str, Enum):
    SUCCEEDED = "succeeded"
    SKIPPED = "skipped"
    FAILED = "failed"


@dataclass(frozen=True)
class Pose2D:
    x: float
    y: float
    yaw: float


@dataclass(frozen=True)
class InspectionPoint:
    point_id: str
    name: str
    point_type: PointType
    pose: Pose2D
    stay_time: float
    allow_skip: bool

    @property
    def x(self) -> float:
        return self.pose.x

    @property
    def y(self) -> float:
        return self.pose.y

    @property
    def yaw(self) -> float:
        return self.pose.yaw


@dataclass(frozen=True)
class MissionTemplate:
    mission_id: str
    name: str
    point_ids: tuple[str, ...]
    nav_bt: str
    stop_on_required_point_failure: bool


@dataclass(frozen=True)
class InspectionOutcome:
    success: bool
    message: str
