"""Safe loading and validation for inspection point and mission YAML files."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

import yaml

from .models import InspectionPoint, MissionTemplate, PointType, Pose2D


class ConfigError(ValueError):
    """Raised when an inspection configuration is missing or invalid."""


@dataclass(frozen=True)
class InspectionConfig:
    points: Mapping[str, InspectionPoint]
    missions: Mapping[str, MissionTemplate]

    def get_mission(self, mission_id: str) -> MissionTemplate:
        try:
            return self.missions[mission_id]
        except KeyError as exc:
            raise ConfigError(f"unknown mission id: {mission_id}") from exc

    def resolve_points(
        self, mission: MissionTemplate
    ) -> tuple[InspectionPoint, ...]:
        return tuple(self.points[point_id] for point_id in mission.point_ids)


def _read_yaml(path: Path | str) -> Any:
    config_path = Path(path)
    try:
        with config_path.open("r", encoding="utf-8") as stream:
            return yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {config_path}: {exc}") from exc
    except OSError as exc:
        raise ConfigError(
            f"cannot read configuration {config_path}: {exc}"
        ) from exc


def _mapping(value: Any, context: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(f"{context} must be a mapping")
    return value


def _list(value: Any, context: str) -> list[Any]:
    if not isinstance(value, list):
        raise ConfigError(f"{context} must be a list")
    return value


def _text(value: Any, context: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(
            f"{context} must be a non-empty string"
        )
    return value.strip()


def _identifier(value: Any, context: str) -> str:
    identifier = _text(value, context)
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", identifier) is None:
        raise ConfigError(
            f"{context} must use 1-64 ASCII letters, digits, '_' or '-'"
        )
    return identifier


def _finite_number(value: Any, context: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ConfigError(f"{context} must be a finite number")
    number = float(value)
    if not math.isfinite(number):
        raise ConfigError(f"{context} must be a finite number")
    return number


def _boolean(value: Any, context: str) -> bool:
    if not isinstance(value, bool):
        raise ConfigError(f"{context} must be a boolean")
    return value


def load_inspection_points(path: Path | str) -> Mapping[str, InspectionPoint]:
    document = _mapping(_read_yaml(path), "points document")
    entries = _list(document.get("points"), "points")
    points: dict[str, InspectionPoint] = {}

    for index, raw_entry in enumerate(entries):
        entry = _mapping(raw_entry, f"points[{index}]")
        point_id = _identifier(entry.get("id"), f"points[{index}].id")
        if point_id in points:
            raise ConfigError(f"duplicate point id: {point_id}")

        type_name = _text(entry.get("type"), f"point {point_id}.type")
        try:
            point_type = PointType(type_name)
        except ValueError as exc:
            raise ConfigError(
                f"unknown point type for {point_id}: {type_name}"
            ) from exc

        pose_entry = _mapping(
            entry.get("pose"), f"point {point_id}.pose"
        )
        pose = Pose2D(
            x=_finite_number(pose_entry.get("x"), f"point {point_id}.pose.x"),
            y=_finite_number(pose_entry.get("y"), f"point {point_id}.pose.y"),
            yaw=_finite_number(
                pose_entry.get("yaw"),
                f"point {point_id}.pose.yaw",
            ),
        )
        stay_time = _finite_number(
            entry.get("stay_time"),
            f"point {point_id}.stay_time",
        )
        if stay_time < 0:
            raise ConfigError(
                f"point {point_id}.stay_time must be non-negative"
            )

        points[point_id] = InspectionPoint(
            point_id=point_id,
            name=_text(entry.get("name"), f"point {point_id}.name"),
            point_type=point_type,
            pose=pose,
            stay_time=stay_time,
            allow_skip=_boolean(
                entry.get("allow_skip"),
                f"point {point_id}.allow_skip",
            ),
        )

    if not points:
        raise ConfigError("points must contain at least one entry")
    return MappingProxyType(points)


def _behavior_tree_path(nav_bt: str, behavior_tree_dir: Path | str) -> Path:
    relative = Path(nav_bt)
    if (
        relative.is_absolute()
        or len(relative.parts) != 1
        or relative.suffix != ".xml"
    ):
        raise ConfigError(f"nav_bt must be a local XML filename: {nav_bt}")

    base = Path(behavior_tree_dir).resolve()
    candidate = (base / relative).resolve()
    if candidate.parent != base:
        raise ConfigError(f"nav_bt escapes behavior tree directory: {nav_bt}")
    if not candidate.is_file():
        raise ConfigError(f"behavior tree does not exist: {candidate}")
    return candidate


def load_mission_templates(
    path: Path | str,
    points: Mapping[str, InspectionPoint],
    behavior_tree_dir: Path | str,
) -> Mapping[str, MissionTemplate]:
    document = _mapping(_read_yaml(path), "missions document")
    entries = _list(document.get("missions"), "missions")
    missions: dict[str, MissionTemplate] = {}

    for index, raw_entry in enumerate(entries):
        entry = _mapping(raw_entry, f"missions[{index}]")
        mission_id = _identifier(entry.get("id"), f"missions[{index}].id")
        if mission_id in missions:
            raise ConfigError(f"duplicate mission id: {mission_id}")

        raw_point_ids = _list(
            entry.get("points"), f"mission {mission_id}.points"
        )
        point_ids = tuple(
            _text(point_id, f"mission {mission_id}.points[{point_index}]")
            for point_index, point_id in enumerate(raw_point_ids)
        )
        if not point_ids:
            raise ConfigError(f"mission {mission_id}.points must not be empty")
        if len(set(point_ids)) != len(point_ids):
            raise ConfigError(
                f"mission {mission_id} contains duplicate point ids"
            )
        for point_id in point_ids:
            if point_id not in points:
                raise ConfigError(
                    f"mission {mission_id} references unknown point: "
                    f"{point_id}"
                )

        nav_bt = _text(entry.get("nav_bt"), f"mission {mission_id}.nav_bt")
        behavior_tree_path = _behavior_tree_path(nav_bt, behavior_tree_dir)
        missions[mission_id] = MissionTemplate(
            mission_id=mission_id,
            name=_text(entry.get("name"), f"mission {mission_id}.name"),
            point_ids=point_ids,
            nav_bt=str(behavior_tree_path),
            stop_on_required_point_failure=_boolean(
                entry.get("stop_on_required_point_failure"),
                f"mission {mission_id}.stop_on_required_point_failure",
            ),
        )

    if not missions:
        raise ConfigError("missions must contain at least one entry")
    return MappingProxyType(missions)


def load_configuration(
    points_path: Path | str,
    missions_path: Path | str,
    behavior_tree_dir: Path | str,
) -> InspectionConfig:
    points = load_inspection_points(points_path)
    missions = load_mission_templates(missions_path, points, behavior_tree_dir)
    return InspectionConfig(points=points, missions=missions)
