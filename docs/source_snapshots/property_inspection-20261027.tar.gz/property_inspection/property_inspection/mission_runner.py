"""Sequential property-inspection mission state machine."""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Mapping

from .models import (
    InspectionPoint,
    MissionState,
    MissionTemplate,
    NavigationResult,
    PointStatus,
)


@dataclass(frozen=True)
class MissionRunResult:
    state: MissionState
    succeeded: int
    failed: int
    skipped: int
    report_path: str
    message: str = ''


class MissionRunner:
    def __init__(
        self,
        navigator,
        inspector,
        reporter,
        state_callback: Callable[[MissionState], None] | None = None,
        utc_now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._navigator = navigator
        self._inspector = inspector
        self._reporter = reporter
        self._state_callback = state_callback or (lambda _state: None)
        self._utc_now = utc_now
        self._monotonic = monotonic
        self.state = MissionState.IDLE

    def _transition(self, state: MissionState) -> None:
        self.state = state
        self._state_callback(state)

    def _iso_now(self) -> str:
        return self._utc_now().astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')

    def run(
        self,
        mission: MissionTemplate,
        points: Mapping[str, InspectionPoint],
    ) -> MissionRunResult:
        self._transition(MissionState.LOAD_MISSION)
        self._reporter.start(mission)
        succeeded = failed = skipped = 0
        final_message = ''

        for point_id in mission.point_ids:
            point = points[point_id]
            self._transition(MissionState.NAVIGATING)
            started_iso = self._iso_now()
            started_mono = self._monotonic()
            navigation_result = self._navigator.navigate_to(point.pose, mission.nav_bt)
            inspection_result = 'not_run'
            message = ''

            if navigation_result is NavigationResult.SUCCESS:
                self._transition(MissionState.INSPECTING)
                outcome = self._inspector.execute(point)
                inspection_result = 'success' if outcome.success else 'failed'
                message = outcome.message
                if outcome.success:
                    status = PointStatus.SUCCEEDED
                    succeeded += 1
                elif point.allow_skip:
                    status = PointStatus.SKIPPED
                    skipped += 1
                else:
                    status = PointStatus.FAILED
                    failed += 1
            else:
                message = f'Navigation ended with {navigation_result.value}'
                if point.allow_skip:
                    status = PointStatus.SKIPPED
                    skipped += 1
                else:
                    status = PointStatus.FAILED
                    failed += 1

            self._transition(MissionState.LOGGING)
            self._reporter.record_point({
                'mission_id': mission.mission_id,
                'mission_name': mission.name,
                'point_id': point.point_id,
                'point_name': point.name,
                'point_type': point.point_type.value,
                'start_time': started_iso,
                'end_time': self._iso_now(),
                'duration_sec': round(self._monotonic() - started_mono, 6),
                'navigation_result': navigation_result.value,
                'inspection_result': inspection_result,
                'status': status.value,
                'allow_skip': point.allow_skip,
                'message': message,
            })

            if status is PointStatus.FAILED:
                final_message = f'Required point failed: {point.point_id}'
                self._transition(MissionState.ABORTED)
                report = self._reporter.finalize(self.state, final_message)
                return MissionRunResult(
                    self.state, succeeded, failed, skipped, str(report), final_message
                )

        self._transition(MissionState.FINISHED)
        report = self._reporter.finalize(self.state)
        return MissionRunResult(
            self.state, succeeded, failed, skipped, str(report), final_message
        )
