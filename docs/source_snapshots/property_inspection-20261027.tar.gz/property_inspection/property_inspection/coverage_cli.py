"""Command-line client for the session coverage task node."""

import argparse
import json
import math
import sys

import rclpy
from rcl_interfaces.msg import Parameter as ParameterMsg
from rcl_interfaces.msg import ParameterType, ParameterValue
from rcl_interfaces.srv import SetParameters
from rclpy.node import Node
from std_srvs.srv import Trigger


COMMAND_SERVICES = {
    "start": "start",
    "cancel": "cancel",
    "status": "status",
    "clear": "clear",
    "undo-point": "undo_point",
    "close-outer": "close_outer",
    "begin-hole": "begin_hole",
    "close-hole": "close_hole",
}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="coverage_cli", description="Control the RViz coverage session"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    start = subparsers.add_parser("start", help="start an asynchronous coverage task")
    start.add_argument("--operation-width", type=float, default=None)
    start.add_argument(
        "--swath-angle-deg",
        default=None,
        help="counterclockwise map angle in degrees, or 'auto'",
    )
    for command in COMMAND_SERVICES:
        if command != "start":
            subparsers.add_parser(command)
    return parser


def _parameter(name: str, value: float) -> ParameterMsg:
    return ParameterMsg(
        name=name,
        value=ParameterValue(
            type=ParameterType.PARAMETER_DOUBLE, double_value=float(value)
        ),
    )


def _wait(node: Node, future, timeout: float = 10.0):
    rclpy.spin_until_future_complete(node, future, timeout_sec=timeout)
    if not future.done():
        raise TimeoutError("request timed out")
    return future.result()


def _set_start_parameters(node: Node, arguments) -> None:
    parameters = []
    if arguments.operation_width is not None:
        if not math.isfinite(arguments.operation_width) or arguments.operation_width <= 0.0:
            raise ValueError("--operation-width must be a positive number")
        parameters.append(_parameter("operation_width", arguments.operation_width))
    if arguments.swath_angle_deg is not None:
        text = arguments.swath_angle_deg.strip().lower()
        if text == "auto":
            angle = float("nan")
        else:
            angle = float(text)
            if not math.isfinite(angle):
                raise ValueError("--swath-angle-deg must be finite or 'auto'")
        parameters.append(_parameter("swath_angle_deg", angle))
    if not parameters:
        return
    client = node.create_client(SetParameters, "/coverage_task_node/set_parameters")
    if not client.wait_for_service(timeout_sec=5.0):
        raise RuntimeError("coverage_task_node parameter service is unavailable")
    request = SetParameters.Request(parameters=parameters)
    response = _wait(node, client.call_async(request))
    rejected = [result.reason for result in response.results if not result.successful]
    if rejected:
        raise RuntimeError("parameter update rejected: " + "; ".join(rejected))


def main(argv=None) -> None:
    arguments = _parser().parse_args(argv)
    rclpy.init(args=None)
    node = Node("coverage_cli")
    exit_code = 0
    try:
        if arguments.command == "start":
            _set_start_parameters(node, arguments)
        service_name = COMMAND_SERVICES[arguments.command]
        client = node.create_client(Trigger, f"/coverage/{service_name}")
        if not client.wait_for_service(timeout_sec=5.0):
            raise RuntimeError(f"/coverage/{service_name} is unavailable")
        response = _wait(node, client.call_async(Trigger.Request()))
        if arguments.command == "status" or response.message.startswith("{"):
            try:
                print(json.dumps(json.loads(response.message), ensure_ascii=False, indent=2))
            except json.JSONDecodeError:
                print(response.message)
        else:
            print(response.message)
        exit_code = 0 if response.success else 2
    except (RuntimeError, TimeoutError, ValueError) as error:
        print(f"coverage_cli: {error}", file=sys.stderr)
        exit_code = 2
    finally:
        node.destroy_node()
        rclpy.shutdown()
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
