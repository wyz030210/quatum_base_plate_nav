"""Deterministic simulated inspection actions for phase 1."""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

from .models import InspectionOutcome


_SUCCESS_MESSAGES = {
    "security": "模拟安防巡检正常",
    "facility": "模拟拍照及设备状态检查正常",
    "environment": "模拟环境卫生检查正常",
    "dock": "到达回充点，任务收尾",
}


class SimulatedInspectionExecutor:
    """Run a repeatable, side-effect-free inspection after navigation succeeds."""

    def __init__(self, sleep: Callable[[float], None] = time.sleep) -> None:
        self._sleep = sleep

    def execute(self, point: Any) -> InspectionOutcome:
        point_type = getattr(point.point_type, "value", point.point_type)
        try:
            message = _SUCCESS_MESSAGES[point_type]
        except KeyError as exc:
            raise ValueError(
                f"unsupported inspection point type: {point_type}"
            ) from exc

        stay_time = float(point.stay_time)
        if stay_time > 0.0:
            self._sleep(stay_time)
        return InspectionOutcome(success=True, message=message)
