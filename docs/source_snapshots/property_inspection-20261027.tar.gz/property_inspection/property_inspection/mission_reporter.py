"""Incremental, durable mission reports for the phase 1 patrol loop."""

from __future__ import annotations

import csv
import json
import os
import re
import tempfile
import time
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, TextIO


POINT_FIELDS = (
    "mission_id",
    "mission_name",
    "point_id",
    "point_name",
    "point_type",
    "start_time",
    "end_time",
    "duration_sec",
    "navigation_result",
    "inspection_result",
    "status",
    "allow_skip",
    "message",
)


def _utc_iso(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    value = value.astimezone(timezone.utc)
    return value.isoformat(timespec="seconds").replace("+00:00", "Z")


def _wire_value(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, datetime):
        return _utc_iso(value)
    if isinstance(value, Path):
        return str(value)
    return value


class MissionReporter:
    """Write one mission's point records and final summary."""

    def __init__(
        self,
        report_root: Path | str,
        *,
        utc_now: Callable[[], datetime] | None = None,
        monotonic: Callable[[], float] | None = None,
    ) -> None:
        self._report_root = Path(report_root).expanduser()
        self._utc_now = utc_now or (lambda: datetime.now(timezone.utc))
        self._monotonic = monotonic or time.monotonic
        self._mission: Any | None = None
        self._start_time: datetime | None = None
        self._start_monotonic: float | None = None
        self._jsonl: TextIO | None = None
        self._records: list[dict[str, Any]] = []
        self._finalized = False
        self.run_dir: Path | None = None

    def start(self, mission: Any) -> Path:
        if self._mission is not None:
            raise RuntimeError("mission report already started")

        started_at = self._utc_now()
        mission_id = str(mission.mission_id)
        if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", mission_id) is None:
            raise ValueError("mission_id is not a safe report-directory identifier")
        timestamp = started_at.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        directory_name = f"mission_{timestamp}_{mission_id}"
        self._report_root.mkdir(parents=True, exist_ok=True)
        for collision_index in range(1000):
            suffix = "" if collision_index == 0 else f"_{collision_index:02d}"
            run_dir = self._report_root / f"{directory_name}{suffix}"
            try:
                run_dir.mkdir(parents=False, exist_ok=False)
                break
            except FileExistsError:
                continue
        else:
            raise RuntimeError("could not allocate a unique report directory")

        self._mission = mission
        self._start_time = started_at
        self._start_monotonic = self._monotonic()
        self.run_dir = run_dir
        self._jsonl = (run_dir / "point_records.jsonl").open(
            "w", encoding="utf-8", newline="\n"
        )
        return run_dir

    def record_point(self, record: Mapping[str, Any]) -> None:
        self._require_active()
        assert self._mission is not None
        assert self._jsonl is not None

        required = set(POINT_FIELDS) - {"mission_id", "mission_name"}
        missing = sorted(
            field for field in required
            if field not in record or record[field] is None
        )
        if missing:
            raise ValueError(
                "point record missing required fields: " + ", ".join(missing)
            )

        projected = {
            field: _wire_value(record.get(field))
            for field in POINT_FIELDS
        }
        if projected["mission_id"] is None:
            projected["mission_id"] = str(self._mission.mission_id)
        if projected["mission_name"] is None:
            projected["mission_name"] = str(self._mission.name)

        self._records.append(projected)
        json.dump(projected, self._jsonl, ensure_ascii=False, separators=(",", ":"))
        self._jsonl.write("\n")
        self._jsonl.flush()

    def finalize(self, mission_state: Any, message: str = "") -> Path:
        self._require_active()
        assert self._mission is not None
        assert self._start_time is not None
        assert self._start_monotonic is not None
        assert self._jsonl is not None
        assert self.run_dir is not None

        ended_at = self._utc_now()
        duration = max(0.0, float(self._monotonic() - self._start_monotonic))
        statuses = [str(record["status"]).lower() for record in self._records]
        total_points = len(getattr(self._mission, "point_ids", self._records))
        summary = {
            "mission_id": str(self._mission.mission_id),
            "mission_name": str(self._mission.name),
            "final_status": _wire_value(mission_state),
            "start_time": _utc_iso(self._start_time),
            "end_time": _utc_iso(ended_at),
            "duration_sec": round(duration, 6),
            "total_points": total_points,
            "success_count": sum(
                status in {"success", "succeeded"} for status in statuses
            ),
            "failed_count": statuses.count("failed"),
            "skipped_count": statuses.count("skipped"),
            "last_processed_point": (
                self._records[-1]["point_id"] if self._records else None
            ),
            "report_dir": str(self.run_dir.resolve()),
            "message": message,
        }

        self._jsonl.close()
        self._jsonl = None
        self._atomic_json(self.run_dir / "summary.json", summary)
        self._atomic_csv(self.run_dir / "summary.csv", self._records)
        self._finalized = True
        return self.run_dir / "summary.json"

    def _require_active(self) -> None:
        if self._finalized:
            raise RuntimeError("mission report already finalized")
        if self._mission is None:
            raise RuntimeError("mission report not started")

    @staticmethod
    def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
        temporary = MissionReporter._temporary_path(path)
        try:
            with temporary.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    @staticmethod
    def _atomic_csv(path: Path, records: list[dict[str, Any]]) -> None:
        temporary = MissionReporter._temporary_path(path)
        try:
            with temporary.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=POINT_FIELDS)
                writer.writeheader()
                writer.writerows(records)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    @staticmethod
    def _temporary_path(path: Path) -> Path:
        descriptor, name = tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
        )
        os.close(descriptor)
        return Path(name)
