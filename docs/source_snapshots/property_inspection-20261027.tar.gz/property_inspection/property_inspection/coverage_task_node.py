"""ROS node that edits a field and executes an OpenNav coverage task."""

import json
import math
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import rclpy
from action_msgs.msg import GoalStatus, GoalStatusArray
from geometry_msgs.msg import Point, PointStamped, PoseWithCovarianceStamped, Twist
from lifecycle_msgs.srv import GetState
from nav2_msgs.action import ComputePathToPose, FollowPath, NavigateToPose
from nav_msgs.msg import Odometry, Path as NavPath
from opennav_coverage_msgs.action import ComputeCoveragePath
from opennav_coverage_msgs.msg import Coordinate, Coordinates
from rcl_interfaces.msg import Parameter as ParameterMsg
from rcl_interfaces.msg import ParameterType, ParameterValue
from rcl_interfaces.srv import SetParameters
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from std_srvs.srv import Trigger
from tf2_ros import Buffer, TransformException, TransformListener
from unique_identifier_msgs.msg import UUID as GoalUUID
from visualization_msgs.msg import Marker, MarkerArray

from .coverage.metrics import (
    DistanceAccumulator,
    covered_area_ratio,
    path_completion,
    polyline_length,
)
from .coverage.models import CoverageState, EditMode, LastResult, Point2D
from .coverage.region_editor import RegionEditor


ACTIVE_GOAL_STATUSES = {
    GoalStatus.STATUS_ACCEPTED,
    GoalStatus.STATUS_EXECUTING,
    GoalStatus.STATUS_CANCELING,
}


def _duration_seconds(duration) -> float:
    return float(duration.sec) + float(duration.nanosec) / 1.0e9


def _yaw_from_quaternion(quaternion) -> float:
    return math.atan2(
        2.0 * (quaternion.w * quaternion.z + quaternion.x * quaternion.y),
        1.0 - 2.0 * (quaternion.y ** 2 + quaternion.z ** 2),
    )


def _angle_difference(a: float, b: float) -> float:
    return abs(math.atan2(math.sin(a - b), math.cos(a - b)))


class CoverageTaskNode(Node):
    """Owns one session's region, actions, metrics, and reports."""

    def __init__(self) -> None:
        super().__init__("coverage_task_node")
        self._group = ReentrantCallbackGroup()
        self._lock = threading.RLock()
        self._declare_parameters()
        self._editor = RegionEditor()
        self._state = CoverageState.IDLE
        self._phase = "IDLE"
        self._last = LastResult()
        self._last_error = None
        self._task = None
        self._active_goal_handle = None
        self._active_action = None
        self._own_goal_ids = {"navigate": set(), "follow": set()}
        self._external_active = {"navigate": False, "follow": False}
        self._cancel_requested = False
        self._pending_terminal = None
        self._stop_started = None
        self._stopped_since = None
        self._latest_linear_speed = float("inf")
        self._latest_angular_speed = float("inf")
        self._initialpose_seen = False
        self._amcl_pose_after_initial = False
        self._amcl_state_future = None
        self._coverage_param_future = None
        self._dependency_deadline = None
        self._phase_deadline = None

        self._approach_distance = DistanceAccumulator()
        self._coverage_distance = DistanceAccumulator()
        self._trace = []
        self._tf_dropped = 0

        self._tf_buffer = Buffer()
        self._tf_listener = TransformListener(self._tf_buffer, self)
        self._coverage_client = ActionClient(
            self,
            ComputeCoveragePath,
            "compute_coverage_path",
            callback_group=self._group,
        )
        self._navigate_client = ActionClient(
            self,
            NavigateToPose,
            "navigate_to_pose",
            callback_group=self._group,
        )
        self._follow_client = ActionClient(
            self,
            FollowPath,
            "follow_path",
            callback_group=self._group,
        )
        self._compute_path_client = ActionClient(
            self,
            ComputePathToPose,
            "compute_path_to_pose",
            callback_group=self._group,
        )
        self._amcl_state_client = self.create_client(
            GetState, "/amcl/get_state", callback_group=self._group
        )
        self._coverage_params_client = self.create_client(
            SetParameters,
            "/coverage_server/set_parameters",
            callback_group=self._group,
        )

        marker_qos = QoSProfile(depth=1)
        marker_qos.reliability = ReliabilityPolicy.RELIABLE
        marker_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self._marker_pub = self.create_publisher(
            MarkerArray, "/coverage/region_markers", marker_qos
        )
        self._planned_path_pub = self.create_publisher(
            NavPath, "/coverage/planned_path", marker_qos
        )
        self._executed_path_pub = self.create_publisher(
            NavPath, "/coverage/executed_path", marker_qos
        )
        self._stop_pub = self.create_publisher(Twist, "/cmd_vel", 10)

        self.create_subscription(
            PointStamped,
            "/clicked_point",
            self._on_clicked_point,
            10,
            callback_group=self._group,
        )
        self.create_subscription(
            PoseWithCovarianceStamped,
            "/initialpose",
            self._on_initial_pose,
            10,
            callback_group=self._group,
        )
        self.create_subscription(
            PoseWithCovarianceStamped,
            "/amcl_pose",
            self._on_amcl_pose,
            10,
            callback_group=self._group,
        )
        self.create_subscription(
            Odometry,
            "/odom",
            self._on_odom,
            30,
            callback_group=self._group,
        )
        self.create_subscription(
            GoalStatusArray,
            "/navigate_to_pose/_action/status",
            lambda msg: self._on_action_status("navigate", msg),
            10,
            callback_group=self._group,
        )
        self.create_subscription(
            GoalStatusArray,
            "/follow_path/_action/status",
            lambda msg: self._on_action_status("follow", msg),
            10,
            callback_group=self._group,
        )

        for name, callback in {
            "start": self._start,
            "cancel": self._cancel,
            "status": self._status,
            "clear": self._clear,
            "undo_point": self._undo,
            "close_outer": self._close_outer,
            "begin_hole": self._begin_hole,
            "close_hole": self._close_hole,
        }.items():
            self.create_service(
                Trigger,
                f"/coverage/{name}",
                callback,
                callback_group=self._group,
            )
        self.create_timer(0.1, self._tick, callback_group=self._group)
        self._publish_region()
        self.get_logger().info(
            "Coverage task node ready; set initial pose and draw an outer boundary"
        )

    def _declare_parameters(self) -> None:
        defaults = {
            "operation_width": 0.5,
            "swath_angle_deg": float("nan"),
            "headland_width": 0.25,
            "dependency_timeout_sec": 30.0,
            "planning_timeout_sec": 120.0,
            "navigate_to_start_timeout_sec": 120.0,
            "follow_path_timeout_sec": 1800.0,
            "cancel_timeout_sec": 5.0,
            "stop_timeout_sec": 5.0,
            "tf_max_age_sec": 1.0,
            "start_position_tolerance": 0.15,
            "start_yaw_tolerance": 0.35,
            "controller_id": "CoverageFollowPath",
            "report_dir": "~/.ros/property_inspection/reports/coverage",
            "opennav_version": "humble-v2@81b63a720d97e0966548d9f062fc6a723f329022",
            "fields2cover_version": "v2.0.0@3613525c241538fa9fd9df3e1209ae8184627958",
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)

    def _idle_edit(self, response, action) -> object:
        with self._lock:
            if self._state != CoverageState.IDLE:
                response.success = False
                response.message = "region editing is disabled while a task is active"
                return response
            try:
                action()
                self._publish_region()
                response.success = True
                response.message = self._editor.mode.value
            except ValueError as error:
                response.success = False
                response.message = str(error)
        return response

    def _clear(self, _request, response):
        return self._idle_edit(response, self._editor.clear)

    def _undo(self, _request, response):
        return self._idle_edit(response, self._editor.undo)

    def _close_outer(self, _request, response):
        width = self.get_parameter("operation_width").value
        return self._idle_edit(response, lambda: self._editor.close_outer(width))

    def _begin_hole(self, _request, response):
        return self._idle_edit(response, self._editor.begin_hole)

    def _close_hole(self, _request, response):
        width = self.get_parameter("operation_width").value
        return self._idle_edit(response, lambda: self._editor.close_hole(width))

    def _on_clicked_point(self, message: PointStamped) -> None:
        with self._lock:
            if self._state != CoverageState.IDLE:
                self.get_logger().warning("Ignoring point while coverage task is active")
                return
            try:
                point = self._point_in_map(message)
                self._editor.add_point(point)
                self._publish_region()
            except (ValueError, TransformException) as error:
                self.get_logger().warning(f"Rejected clicked point: {error}")

    def _point_in_map(self, message: PointStamped) -> Point2D:
        if message.header.frame_id in ("", "map"):
            return Point2D(message.point.x, message.point.y)
        transform = self._tf_buffer.lookup_transform(
            "map", message.header.frame_id, Time.from_msg(message.header.stamp)
        )
        yaw = _yaw_from_quaternion(transform.transform.rotation)
        x = (
            math.cos(yaw) * message.point.x
            - math.sin(yaw) * message.point.y
            + transform.transform.translation.x
        )
        y = (
            math.sin(yaw) * message.point.x
            + math.cos(yaw) * message.point.y
            + transform.transform.translation.y
        )
        return Point2D(x, y)

    def _on_initial_pose(self, _message) -> None:
        with self._lock:
            self._initialpose_seen = True
            self._amcl_pose_after_initial = False

    def _on_amcl_pose(self, _message) -> None:
        with self._lock:
            if self._initialpose_seen:
                self._amcl_pose_after_initial = True

    def _start(self, _request, response):
        with self._lock:
            if self._state != CoverageState.IDLE:
                response.success = False
                response.message = f"task already active: {self._state.value}"
                return response
            if not self._initialpose_seen or not self._amcl_pose_after_initial:
                response.success = False
                response.message = (
                    "set 2D Pose Estimate after coverage_task_node starts and wait for AMCL"
                )
                return response
            if any(self._external_active.values()):
                response.success = False
                response.message = "another Nav2 action is active"
                return response
            width = float(self.get_parameter("operation_width").value)
            try:
                region = self._editor.snapshot(width)
            except ValueError as error:
                response.success = False
                response.message = str(error)
                return response
            now_wall = time.monotonic()
            self._task = {
                "id": str(uuid.uuid4()),
                "region": region,
                "operation_width": width,
                "swath_angle_deg": self.get_parameter("swath_angle_deg").value,
                "started_utc": datetime.now(timezone.utc).isoformat(),
                "started_monotonic": now_wall,
                "planning_time_sec": None,
                "approach_planned_distance_m": None,
                "approach_started": None,
                "approach_elapsed_sec": 0.0,
                "coverage_started": None,
                "coverage_elapsed_sec": 0.0,
                "coverage_path_length_m": 0.0,
                "path_completion_ratio": 0.0,
                "planned_path": None,
            }
            self._approach_distance = DistanceAccumulator()
            self._coverage_distance = DistanceAccumulator()
            self._trace = []
            self._tf_dropped = 0
            self._last_error = None
            self._cancel_requested = False
            self._pending_terminal = None
            self._state = CoverageState.VALIDATING_REGION
            self._phase = "WAITING_DEPENDENCIES"
            self._dependency_deadline = now_wall + float(
                self.get_parameter("dependency_timeout_sec").value
            )
            self._amcl_state_future = None
            self._coverage_param_future = None
            response.success = True
            response.message = json.dumps(
                {"accepted": True, "task_id": self._task["id"]},
                ensure_ascii=False,
            )
        return response

    def _cancel(self, _request, response):
        with self._lock:
            if self._state == CoverageState.IDLE:
                response.success = True
                response.message = "no active coverage task"
                return response
            self._cancel_requested = True
            handle = self._active_goal_handle
            if handle is not None:
                handle.cancel_goal_async()
            self._request_terminal(CoverageState.CANCELED, "USER_CANCELED", "canceled by user")
            response.success = True
            response.message = "cancel requested"
        return response

    def _status(self, _request, response):
        with self._lock:
            payload = {
                "state": self._state.value,
                "phase": self._phase,
                "edit_mode": self._editor.mode.value,
                "outer_points": len(self._editor.outer),
                "holes": len(self._editor.holes),
                "progress": (
                    self._task["path_completion_ratio"] if self._task else 0.0
                ),
                "last_result": {
                    "status": self._last.status,
                    "error_code": self._last.error_code,
                    "message": self._last.message,
                    "report_path": self._last.report_path,
                },
            }
            response.success = True
            response.message = json.dumps(payload, ensure_ascii=False)
        return response

    def _tick(self) -> None:
        with self._lock:
            now = time.monotonic()
            if self._pending_terminal is not None:
                self._tick_stopping(now)
                return
            if self._state == CoverageState.VALIDATING_REGION:
                self._tick_dependencies(now)
                return
            if self._phase_deadline is not None and now >= self._phase_deadline:
                code = {
                    CoverageState.COMPUTING_PATH: "PLANNING_TIMEOUT",
                    CoverageState.NAVIGATING_TO_START: "NAVIGATE_TO_START_TIMEOUT",
                    CoverageState.FOLLOWING_COVERAGE_PATH: "FOLLOW_PATH_TIMEOUT",
                }.get(self._state, "TASK_TIMEOUT")
                if self._active_goal_handle is not None:
                    self._active_goal_handle.cancel_goal_async()
                self._request_terminal(CoverageState.FAILED, code, "phase timed out")

    def _tick_dependencies(self, now: float) -> None:
        ready = (
            self._coverage_client.server_is_ready()
            and self._navigate_client.server_is_ready()
            and self._follow_client.server_is_ready()
            and self._amcl_state_client.service_is_ready()
            and self._coverage_params_client.service_is_ready()
        )
        if not ready:
            if now >= self._dependency_deadline:
                self._request_terminal(
                    CoverageState.FAILED,
                    "DEPENDENCY_TIMEOUT",
                    "coverage, Nav2, AMCL, or parameter service unavailable",
                )
            return
        if self._amcl_state_future is None:
            self._amcl_state_future = self._amcl_state_client.call_async(GetState.Request())
            self._amcl_state_future.add_done_callback(self._on_amcl_state)

    def _on_amcl_state(self, future) -> None:
        with self._lock:
            if self._state != CoverageState.VALIDATING_REGION:
                return
            try:
                active = future.result().current_state.label == "active"
            except Exception as error:
                self._request_terminal(CoverageState.FAILED, "AMCL_STATE_ERROR", str(error))
                return
            if not active:
                self._request_terminal(
                    CoverageState.FAILED, "AMCL_NOT_ACTIVE", "AMCL is not active"
                )
                return
            if not self._fresh_robot_pose():
                self._request_terminal(
                    CoverageState.FAILED,
                    "TF_UNAVAILABLE",
                    "fresh map to base_link transform is unavailable",
                )
                return
            request = SetParameters.Request()
            parameter = ParameterMsg()
            parameter.name = "operation_width"
            parameter.value = ParameterValue(
                type=ParameterType.PARAMETER_DOUBLE,
                double_value=self._task["operation_width"],
            )
            request.parameters = [parameter]
            self._coverage_param_future = self._coverage_params_client.call_async(request)
            self._coverage_param_future.add_done_callback(self._on_coverage_params_set)

    def _on_coverage_params_set(self, future) -> None:
        with self._lock:
            if self._state != CoverageState.VALIDATING_REGION:
                return
            try:
                results = future.result().results
                success = len(results) == 1 and results[0].successful
                reason = "" if success else results[0].reason
            except Exception as error:
                success, reason = False, str(error)
            if not success:
                self._request_terminal(
                    CoverageState.FAILED,
                    "OPERATION_WIDTH_SYNC_FAILED",
                    reason or "coverage server rejected operation_width",
                )
                return
            self._send_coverage_goal()

    def _send_coverage_goal(self) -> None:
        goal = ComputeCoveragePath.Goal()
        goal.generate_decomp = False
        goal.generate_headland = True
        goal.generate_route = True
        goal.generate_path = True
        goal.frame_id = "map"
        goal.headland_mode.mode = "CONSTANT"
        goal.headland_mode.width = float(self.get_parameter("headland_width").value)
        goal.swath_mode.objective = "LENGTH"
        angle = float(self._task["swath_angle_deg"])
        if math.isnan(angle):
            goal.swath_mode.mode = "BRUTE_FORCE"
        else:
            goal.swath_mode.mode = "SET_ANGLE"
            goal.swath_mode.best_angle = math.radians(angle)
        goal.route_mode.mode = "BOUSTROPHEDON"
        goal.path_mode.mode = "DUBIN"
        goal.path_mode.continuity_mode = "CONTINUOUS"
        goal.path_mode.turn_point_distance = 0.05
        for ring in (self._task["region"].outer,) + self._task["region"].holes:
            polygon = Coordinates()
            for point in tuple(ring) + (ring[0],):
                polygon.coordinates.append(Coordinate(axis1=point.x, axis2=point.y))
            goal.polygons.append(polygon)
        # BOUSTROPHEDON routing does not use start_pose in humble-v2.  The
        # generated first pose is approached separately with NavigateToPose.
        goal.use_start_pose = False
        self._state = CoverageState.COMPUTING_PATH
        self._phase = "COMPUTING_PATH"
        self._phase_deadline = time.monotonic() + float(
            self.get_parameter("planning_timeout_sec").value
        )
        send_future = self._coverage_client.send_goal_async(goal)
        send_future.add_done_callback(self._on_coverage_goal)

    def _on_coverage_goal(self, future) -> None:
        with self._lock:
            if self._state != CoverageState.COMPUTING_PATH:
                return
            try:
                handle = future.result()
            except Exception as error:
                self._request_terminal(CoverageState.FAILED, "PLANNER_SEND_ERROR", str(error))
                return
            if handle is None or not handle.accepted:
                self._request_terminal(CoverageState.FAILED, "PLANNER_REJECTED", "goal rejected")
                return
            self._active_goal_handle = handle
            self._active_action = "coverage"
            result_future = handle.get_result_async()
            result_future.add_done_callback(self._on_coverage_result)

    def _on_coverage_result(self, future) -> None:
        with self._lock:
            self._active_goal_handle = None
            self._active_action = None
            if self._pending_terminal is not None:
                return
            try:
                wrapped = future.result()
                result = wrapped.result
            except Exception as error:
                self._request_terminal(CoverageState.FAILED, "PLANNER_RESULT_ERROR", str(error))
                return
            if wrapped.status != GoalStatus.STATUS_SUCCEEDED or result.error_code != 0:
                self._request_terminal(
                    CoverageState.FAILED,
                    "PLANNING_FAILED",
                    f"status={wrapped.status}, error_code={result.error_code}",
                )
                return
            path = result.nav_path
            path_stamp = self.get_clock().now().to_msg()
            for stamped in path.poses:
                # OpenNav humble-v2 sets nav_path.header but leaves the
                # individual PoseStamped headers empty. Nav2 actions require
                # every goal/path pose to carry its frame explicitly.
                stamped.header.frame_id = "map"
                stamped.header.stamp = path_stamp
            flags = list(result.coverage_path.is_backward)
            if not path.poses:
                self._request_terminal(
                    CoverageState.FAILED, "EMPTY_PATH", "planner returned no poses"
                )
                return
            if path.header.frame_id != "map":
                self._request_terminal(
                    CoverageState.FAILED, "INVALID_PATH_FRAME", path.header.frame_id
                )
                return
            if len(flags) != len(path.poses) or any(flags):
                self._request_terminal(
                    CoverageState.FAILED,
                    "REVERSE_PATH_REJECTED",
                    "direction flags are missing or contain reverse motion",
                )
                return
            coordinates = []
            for stamped in path.poses:
                x, y = stamped.pose.position.x, stamped.pose.position.y
                if not (math.isfinite(x) and math.isfinite(y)):
                    self._request_terminal(CoverageState.FAILED, "INVALID_PATH", "non-finite pose")
                    return
                coordinates.append((x, y))
            length = polyline_length(coordinates)
            if length <= 0.0:
                self._request_terminal(CoverageState.FAILED, "EMPTY_PATH", "zero-length path")
                return
            self._task["planning_time_sec"] = _duration_seconds(result.planning_time)
            self._task["coverage_path_length_m"] = length
            self._task["planned_path"] = path
            self._planned_path_pub.publish(path)
            self._prepare_approach(path)

    def _prepare_approach(self, path: NavPath) -> None:
        robot = self._robot_pose()
        if robot is None:
            self._request_terminal(
                CoverageState.FAILED, "TF_UNAVAILABLE", "robot pose unavailable"
            )
            return
        first = path.poses[0]
        first_yaw = _yaw_from_quaternion(first.pose.orientation)
        distance = math.hypot(first.pose.position.x - robot[0], first.pose.position.y - robot[1])
        yaw_error = _angle_difference(first_yaw, robot[2])
        if (
            distance <= float(self.get_parameter("start_position_tolerance").value)
            and yaw_error <= float(self.get_parameter("start_yaw_tolerance").value)
        ):
            self._send_follow_goal()
            return
        if self._compute_path_client.server_is_ready():
            goal = ComputePathToPose.Goal()
            goal.goal = first
            goal.use_start = False
            future = self._compute_path_client.send_goal_async(goal)
            future.add_done_callback(self._on_approach_plan_goal)
        else:
            self._send_navigate_goal()

    def _on_approach_plan_goal(self, future) -> None:
        with self._lock:
            try:
                handle = future.result()
            except Exception:
                handle = None
            if handle is None or not handle.accepted:
                self._send_navigate_goal()
                return
            handle.get_result_async().add_done_callback(self._on_approach_plan_result)

    def _on_approach_plan_result(self, future) -> None:
        with self._lock:
            try:
                wrapped = future.result()
                if wrapped.status == GoalStatus.STATUS_SUCCEEDED:
                    poses = wrapped.result.path.poses
                    self._task["approach_planned_distance_m"] = polyline_length(
                        (pose.pose.position.x, pose.pose.position.y) for pose in poses
                    )
            except Exception:
                pass
            self._send_navigate_goal()

    def _send_navigate_goal(self) -> None:
        if self._pending_terminal is not None:
            return
        goal = NavigateToPose.Goal()
        goal.pose = self._task["planned_path"].poses[0]
        self._state = CoverageState.NAVIGATING_TO_START
        self._phase = "NAVIGATING_TO_START"
        self._task["approach_started"] = time.monotonic()
        self._approach_distance.reset_segment()
        self._phase_deadline = time.monotonic() + float(
            self.get_parameter("navigate_to_start_timeout_sec").value
        )
        goal_id = GoalUUID(uuid=list(uuid.uuid4().bytes))
        goal_id_bytes = bytes(goal_id.uuid)
        self._own_goal_ids["navigate"].add(goal_id_bytes)
        future = self._navigate_client.send_goal_async(goal, goal_uuid=goal_id)
        future.add_done_callback(
            lambda item: self._on_motion_goal("navigate", goal_id_bytes, item)
        )

    def _send_follow_goal(self) -> None:
        if self._pending_terminal is not None:
            return
        goal = FollowPath.Goal()
        goal.path = self._task["planned_path"]
        goal.controller_id = self.get_parameter("controller_id").value
        self._state = CoverageState.FOLLOWING_COVERAGE_PATH
        self._phase = "FOLLOWING_COVERAGE_PATH"
        self._task["coverage_started"] = time.monotonic()
        self._coverage_distance.reset_segment()
        self._phase_deadline = time.monotonic() + float(
            self.get_parameter("follow_path_timeout_sec").value
        )
        goal_id = GoalUUID(uuid=list(uuid.uuid4().bytes))
        goal_id_bytes = bytes(goal_id.uuid)
        self._own_goal_ids["follow"].add(goal_id_bytes)
        future = self._follow_client.send_goal_async(
            goal,
            feedback_callback=self._on_follow_feedback,
            goal_uuid=goal_id,
        )
        future.add_done_callback(
            lambda item: self._on_motion_goal("follow", goal_id_bytes, item)
        )

    def _on_motion_goal(self, action: str, goal_id: bytes, future) -> None:
        with self._lock:
            if self._pending_terminal is not None:
                return
            try:
                handle = future.result()
            except Exception as error:
                self._own_goal_ids[action].discard(goal_id)
                self._request_terminal(CoverageState.FAILED, "ACTION_SEND_ERROR", str(error))
                return
            if handle is None or not handle.accepted:
                self._own_goal_ids[action].discard(goal_id)
                self._request_terminal(CoverageState.FAILED, "ACTION_REJECTED", action)
                return
            self._active_goal_handle = handle
            self._active_action = action
            handle.get_result_async().add_done_callback(
                lambda item: self._on_motion_result(action, item)
            )

    def _on_motion_result(self, action: str, future) -> None:
        with self._lock:
            self._active_goal_handle = None
            self._active_action = None
            if action == "navigate" and self._task["approach_started"] is not None:
                self._task["approach_elapsed_sec"] = (
                    time.monotonic() - self._task["approach_started"]
                )
            if action == "follow" and self._task["coverage_started"] is not None:
                self._task["coverage_elapsed_sec"] = (
                    time.monotonic() - self._task["coverage_started"]
                )
            if self._pending_terminal is not None:
                return
            try:
                wrapped = future.result()
                status = wrapped.status
            except Exception as error:
                self._request_terminal(CoverageState.FAILED, "ACTION_RESULT_ERROR", str(error))
                return
            if status != GoalStatus.STATUS_SUCCEEDED:
                terminal = (
                    CoverageState.CANCELED
                    if self._cancel_requested
                    else CoverageState.FAILED
                )
                code = "USER_CANCELED" if self._cancel_requested else f"{action.upper()}_FAILED"
                self._request_terminal(terminal, code, f"action status={status}")
                return
            if action == "navigate":
                self._send_follow_goal()
            else:
                self._task["path_completion_ratio"] = 1.0
                self._request_terminal(CoverageState.SUCCEEDED, None, "coverage completed")

    def _on_follow_feedback(self, message) -> None:
        with self._lock:
            if self._task is None:
                return
            completion = path_completion(
                self._task["coverage_path_length_m"], message.feedback.distance_to_goal
            )
            self._task["path_completion_ratio"] = max(
                self._task["path_completion_ratio"], completion
            )

    def _on_action_status(self, action: str, message: GoalStatusArray) -> None:
        with self._lock:
            external = any(
                status.status in ACTIVE_GOAL_STATUSES
                and bytes(status.goal_info.goal_id.uuid) not in self._own_goal_ids[action]
                for status in message.status_list
            )
            # NavigateToPose drives the controller through its own FollowPath
            # child action.  Its UUID is created inside the Nav2 behavior tree,
            # so it cannot be registered in _own_goal_ids.  Treat that child as
            # expected while approaching the coverage path's first pose.
            if action == "follow" and self._state == CoverageState.NAVIGATING_TO_START:
                external = False
            self._external_active[action] = external
            if external and self._state != CoverageState.IDLE and self._pending_terminal is None:
                if self._active_goal_handle is not None:
                    self._active_goal_handle.cancel_goal_async()
                self._request_terminal(
                    CoverageState.FAILED,
                    "EXTERNAL_NAVIGATION_CONFLICT",
                    f"external {action} goal detected",
                )

    def _on_odom(self, message: Odometry) -> None:
        with self._lock:
            self._latest_linear_speed = math.hypot(
                message.twist.twist.linear.x, message.twist.twist.linear.y
            )
            self._latest_angular_speed = abs(message.twist.twist.angular.z)
            x = message.pose.pose.position.x
            y = message.pose.pose.position.y
            if self._state == CoverageState.NAVIGATING_TO_START:
                self._approach_distance.add(x, y)
            elif self._state == CoverageState.FOLLOWING_COVERAGE_PATH:
                self._coverage_distance.add(x, y)
                try:
                    transform = self._tf_buffer.lookup_transform(
                        "map", "base_link", Time()
                    )
                    point = Point2D(
                        transform.transform.translation.x,
                        transform.transform.translation.y,
                    )
                    self._trace.append(point)
                    self._publish_executed_path(message.header.stamp)
                except TransformException:
                    self._tf_dropped += 1

    def _fresh_robot_pose(self) -> bool:
        return self._robot_pose() is not None

    def _robot_pose(self):
        try:
            transform = self._tf_buffer.lookup_transform("map", "base_link", Time())
        except TransformException:
            return None
        stamp = Time.from_msg(transform.header.stamp)
        age = (self.get_clock().now() - stamp).nanoseconds / 1.0e9
        max_age = float(self.get_parameter("tf_max_age_sec").value)
        if age < -0.1 or age > max_age:
            return None
        return (
            transform.transform.translation.x,
            transform.transform.translation.y,
            _yaw_from_quaternion(transform.transform.rotation),
        )

    def _request_terminal(self, state, error_code, message) -> None:
        if self._pending_terminal is not None:
            return
        self._pending_terminal = (state, error_code, message)
        self._state = state
        self._phase = "STOPPING"
        self._phase_deadline = None
        self._stop_started = time.monotonic()
        self._stopped_since = None
        self._stop_pub.publish(Twist())
        if state == CoverageState.FAILED:
            self.get_logger().error(f"Coverage failed [{error_code}]: {message}")

    def _tick_stopping(self, now: float) -> None:
        self._stop_pub.publish(Twist())
        stopped = self._latest_linear_speed < 0.01 and self._latest_angular_speed < 0.02
        if stopped:
            if self._stopped_since is None:
                self._stopped_since = now
            if now - self._stopped_since >= 1.0:
                self._finalize_terminal()
                return
        else:
            self._stopped_since = None
        if now - self._stop_started >= float(self.get_parameter("stop_timeout_sec").value):
            state, code, message = self._pending_terminal
            if state == CoverageState.SUCCEEDED:
                state = CoverageState.FAILED
            self._pending_terminal = (
                state,
                "STOP_TIMEOUT",
                f"{message}; robot did not confirm stop",
            )
            self._finalize_terminal()

    def _finalize_terminal(self) -> None:
        state, code, message = self._pending_terminal
        report_path = None
        try:
            report_path = self._write_report(state, code, message)
        except Exception as error:
            self.get_logger().error(f"Failed to write coverage report: {error}")
            if state == CoverageState.SUCCEEDED:
                state, code = CoverageState.FAILED, "REPORT_WRITE_FAILED"
            message = f"{message}; report error: {error}"
        self._last = LastResult(state.value, code, message, report_path)
        self.get_logger().info(
            f"Coverage task {state.value}: {message} (report={report_path})"
        )
        self._pending_terminal = None
        self._active_goal_handle = None
        self._active_action = None
        self._phase_deadline = None
        self._state = CoverageState.IDLE
        self._phase = "IDLE"

    def _write_report(self, state, code, message) -> str:
        task = self._task
        now = time.monotonic()
        if task["approach_started"] is not None and task["approach_elapsed_sec"] == 0.0:
            task["approach_elapsed_sec"] = now - task["approach_started"]
        if task["coverage_started"] is not None and task["coverage_elapsed_sec"] == 0.0:
            task["coverage_elapsed_sec"] = now - task["coverage_started"]
        area_ratio = covered_area_ratio(
            self._trace, task["region"], task["operation_width"]
        )
        region = task["region"]
        try:
            import shapely
            shapely_version = shapely.__version__
        except (ImportError, AttributeError):
            shapely_version = "unknown"
        payload = {
            "schema_version": "1.0",
            "task_id": task["id"],
            "started_utc": task["started_utc"],
            "ended_utc": datetime.now(timezone.utc).isoformat(),
            "result": {"status": state.value, "error_code": code, "message": message},
            "versions": {
                "opennav_coverage": self.get_parameter("opennav_version").value,
                "fields2cover": self.get_parameter("fields2cover_version").value,
                "property_inspection": "0.1.0",
                "shapely": shapely_version,
            },
            "region": {
                "frame_id": "map",
                "outer": [[point.x, point.y] for point in region.outer],
                "holes": [
                    [[point.x, point.y] for point in hole] for hole in region.holes
                ],
                "operation_width_m": task["operation_width"],
                "swath_angle_deg": (
                    None if math.isnan(float(task["swath_angle_deg"]))
                    else task["swath_angle_deg"]
                ),
            },
            "timing_sec": {
                "planning": task["planning_time_sec"],
                "approach": task["approach_elapsed_sec"],
                "coverage": task["coverage_elapsed_sec"],
                "total": now - task["started_monotonic"],
            },
            "distance_m": {
                "approach_planned": task["approach_planned_distance_m"],
                "approach_actual": self._approach_distance.distance,
                "coverage_planned": task["coverage_path_length_m"],
                "coverage_actual": self._coverage_distance.distance,
                "total_actual": (
                    self._approach_distance.distance + self._coverage_distance.distance
                ),
            },
            "coverage": {
                "path_completion_ratio": task["path_completion_ratio"],
                "area_coverage_ratio": area_ratio,
                "area_method": "map trajectory buffered by half operation width",
            },
            "tf_dropped_samples": self._tf_dropped,
            "collision_assessment": "not_instrumented",
        }
        directory = Path(os.path.expanduser(self.get_parameter("report_dir").value))
        directory.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        target = directory / f"{stamp}_{task['id']}.json"
        temporary = directory / f".{target.name}.tmp"
        with temporary.open("w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        return str(target)

    def _publish_region(self) -> None:
        array = MarkerArray()
        clear = Marker()
        clear.action = Marker.DELETEALL
        array.markers.append(clear)
        rings = [(self._editor.outer, (0.1, 0.9, 0.1))]
        rings.extend((list(hole), (0.9, 0.2, 0.1)) for hole in self._editor.holes)
        if self._editor.draft_hole:
            rings.append((self._editor.draft_hole, (1.0, 0.6, 0.0)))
        stamp = self.get_clock().now().to_msg()
        for marker_id, (ring, color) in enumerate(rings, start=1):
            if not ring:
                continue
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = stamp
            marker.ns = "coverage_region"
            marker.id = marker_id
            marker.type = Marker.LINE_STRIP
            marker.action = Marker.ADD
            marker.scale.x = 0.05
            marker.color.r, marker.color.g, marker.color.b = color
            marker.color.a = 1.0
            marker.points = [Point(x=point.x, y=point.y, z=0.04) for point in ring]
            closed = ring is not self._editor.outer or self._editor.mode != EditMode.OUTER_DRAFT
            if closed and len(ring) >= 3:
                marker.points.append(marker.points[0])
            array.markers.append(marker)
        self._marker_pub.publish(array)

    def _publish_executed_path(self, stamp) -> None:
        path = NavPath()
        path.header.frame_id = "map"
        path.header.stamp = stamp
        from geometry_msgs.msg import PoseStamped
        for point in self._trace:
            pose = PoseStamped()
            pose.header = path.header
            pose.pose.position.x = point.x
            pose.pose.position.y = point.y
            pose.pose.orientation.w = 1.0
            path.poses.append(pose)
        self._executed_path_pub.publish(path)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = CoverageTaskNode()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
