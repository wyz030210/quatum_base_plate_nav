from pathlib import Path

from property_inspection.config_loader import InspectionConfig
from property_inspection.mission_manager_node import (
    abort_active_mission,
    execute_loaded_mission,
    initialize_rclpy,
    runtime_paths,
)
from property_inspection.models import (
    InspectionOutcome,
    InspectionPoint,
    MissionState,
    MissionTemplate,
    NavigationResult,
    PointType,
    Pose2D,
)


class Navigator:
    def __init__(self):
        self.initial_pose = None
        self.waited = False

    def set_initial_pose(self, pose):
        self.initial_pose = pose

    def wait_until_active(self):
        self.waited = True

    def navigate_to(self, _pose, _bt):
        return NavigationResult.SUCCESS


class Inspector:
    def execute(self, _point):
        return InspectionOutcome(True, 'ok')


class Reporter:
    def start(self, _mission):
        return Path('/tmp/report')

    def record_point(self, _record):
        pass

    def finalize(self, _state, _message=''):
        return Path('/tmp/report/summary.json')


def test_runtime_paths_are_below_package_share(tmp_path):
    paths = runtime_paths(tmp_path)

    assert paths.points == tmp_path / 'config/inspection_points.yaml'
    assert paths.missions == tmp_path / 'config/mission_templates.yaml'
    assert paths.behavior_trees == tmp_path / 'behavior_trees'


def test_execute_loaded_mission_sets_pose_waits_and_runs():
    point = InspectionPoint('p1', 'P1', PointType.SECURITY, Pose2D(0.0, 0.0, 0.0), 0.0, True)
    mission = MissionTemplate('mission', 'Mission', ('p1',), '/abs/tree.xml', True)
    config = InspectionConfig(points={'p1': point}, missions={'mission': mission})
    navigator = Navigator()

    result = execute_loaded_mission(
        config,
        'mission',
        navigator,
        Inspector(),
        Reporter(),
        Pose2D(-2.0, -0.5, 0.0),
    )

    assert navigator.initial_pose == Pose2D(-2.0, -0.5, 0.0)
    assert navigator.waited is True
    assert result.state is MissionState.FINISHED


def test_abort_active_mission_cancels_and_finalizes_report():
    class ActiveNavigator:
        canceled = False

        def cancel(self):
            self.canceled = True

    class ActiveReporter(Reporter):
        run_dir = Path('/tmp/report')
        finalized = None

        def finalize(self, state, message=''):
            self.finalized = (state, message)
            return self.run_dir / 'summary.json'

    navigator = ActiveNavigator()
    reporter = ActiveReporter()

    abort_active_mission(navigator, reporter, 'unexpected failure')

    assert navigator.canceled is True
    assert reporter.finalized == (MissionState.ABORTED, 'unexpected failure')


def test_abort_report_is_finalized_even_if_navigation_cancel_fails():
    class BrokenNavigator:
        def cancel(self):
            raise RuntimeError('cancel failed')

    class ActiveReporter(Reporter):
        run_dir = Path('/tmp/report')
        finalized = None

        def finalize(self, state, message=''):
            self.finalized = (state, message)
            return self.run_dir / 'summary.json'

    reporter = ActiveReporter()

    abort_active_mission(BrokenNavigator(), reporter, 'execution failed')

    assert reporter.finalized == (MissionState.ABORTED, 'execution failed')


def test_initialize_rclpy_owns_sigint_and_sigterm(monkeypatch):
    import property_inspection.mission_manager_node as manager

    initialized = {}
    handlers = {}
    monkeypatch.setattr(
        manager.rclpy,
        'init',
        lambda **kwargs: initialized.update(kwargs),
    )
    monkeypatch.setattr(
        manager.signal,
        'signal',
        lambda signum, handler: handlers.setdefault(signum, handler),
    )

    initialize_rclpy(['--test'])

    assert initialized['signal_handler_options'].name == 'NO'
    assert handlers[manager.signal.SIGINT] is manager._raise_keyboard_interrupt
    assert handlers[manager.signal.SIGTERM] is manager._raise_keyboard_interrupt
