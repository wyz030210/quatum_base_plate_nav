from __future__ import annotations

import dataclasses
from pathlib import Path

import pytest

from property_inspection.config_loader import (
    ConfigError,
    load_configuration,
    load_inspection_points,
    load_mission_templates,
)
from property_inspection.models import (
    MissionState,
    NavigationResult,
    PointStatus,
    PointType,
)


VALID_POINTS = """
points:
  - id: gate_1
    name: Gate
    type: security
    pose: {x: 1.0, y: 2.0, yaw: 0.0}
    stay_time: 3.0
    allow_skip: true
"""

VALID_MISSIONS = """
missions:
  - id: night_patrol
    name: Night patrol
    points: [gate_1]
    nav_bt: inspection_nav_to_pose.xml
    stop_on_required_point_failure: true
"""


def write(path: Path, content: str) -> Path:
    path.write_text(content, encoding="utf-8")
    return path


def make_bt_dir(tmp_path: Path) -> Path:
    bt_dir = tmp_path / "behavior_trees"
    bt_dir.mkdir()
    write(bt_dir / "inspection_nav_to_pose.xml", "<root/>")
    return bt_dir


def test_loads_valid_configuration_into_frozen_domain_models(
    tmp_path: Path,
) -> None:
    points_path = write(tmp_path / "points.yaml", VALID_POINTS)
    missions_path = write(tmp_path / "missions.yaml", VALID_MISSIONS)

    config = load_configuration(
        points_path, missions_path, make_bt_dir(tmp_path)
    )

    point = config.points["gate_1"]
    mission = config.get_mission("night_patrol")
    assert point.point_type is PointType.SECURITY
    assert (point.x, point.y, point.yaw) == (1.0, 2.0, 0.0)
    assert mission.point_ids == ("gate_1",)
    assert Path(mission.nav_bt).is_absolute()
    assert config.resolve_points(mission) == (point,)
    with pytest.raises(dataclasses.FrozenInstanceError):
        point.name = "changed"  # type: ignore[misc]


@pytest.mark.parametrize(
    "enum_type",
    [PointType, MissionState, NavigationResult, PointStatus],
)
def test_domain_enums_are_string_enums(enum_type: type) -> None:
    assert all(isinstance(member.value, str) for member in enum_type)


def test_rejects_duplicate_point_ids(tmp_path: Path) -> None:
    points_path = write(
        tmp_path / "points.yaml",
        VALID_POINTS + VALID_POINTS.split("points:\n", 1)[1],
    )

    with pytest.raises(ConfigError, match="duplicate point id.*gate_1"):
        load_inspection_points(points_path)


def test_rejects_unknown_point_type(tmp_path: Path) -> None:
    path = write(
        tmp_path / "points.yaml",
        VALID_POINTS.replace("security", "unknown"),
    )

    with pytest.raises(ConfigError, match="unknown point type"):
        load_inspection_points(path)


@pytest.mark.parametrize("value", [".nan", ".inf", "-.inf"])
def test_rejects_non_finite_pose(tmp_path: Path, value: str) -> None:
    path = write(
        tmp_path / "points.yaml",
        VALID_POINTS.replace("x: 1.0", f"x: {value}"),
    )

    with pytest.raises(ConfigError, match="finite number"):
        load_inspection_points(path)


def test_rejects_mission_point_reference_that_does_not_exist(
    tmp_path: Path,
) -> None:
    missions_path = write(
        tmp_path / "missions.yaml",
        VALID_MISSIONS.replace("gate_1", "missing_point"),
    )
    points = load_inspection_points(
        write(tmp_path / "points.yaml", VALID_POINTS)
    )

    with pytest.raises(ConfigError, match="unknown point.*missing_point"):
        load_mission_templates(missions_path, points, make_bt_dir(tmp_path))


def test_get_mission_rejects_unknown_mission_id(tmp_path: Path) -> None:
    config = load_configuration(
        write(tmp_path / "points.yaml", VALID_POINTS),
        write(tmp_path / "missions.yaml", VALID_MISSIONS),
        make_bt_dir(tmp_path),
    )

    with pytest.raises(ConfigError, match="unknown mission.*does_not_exist"):
        config.get_mission("does_not_exist")


def test_rejects_mission_id_that_could_escape_report_root(tmp_path: Path) -> None:
    missions = VALID_MISSIONS.replace("night_patrol", "../../../escape")
    points = load_inspection_points(
        write(tmp_path / "points.yaml", VALID_POINTS)
    )

    with pytest.raises(ConfigError, match="mission.*id"):
        load_mission_templates(
            write(tmp_path / "missions.yaml", missions),
            points,
            make_bt_dir(tmp_path),
        )


def test_rejects_missing_behavior_tree(tmp_path: Path) -> None:
    points = load_inspection_points(
        write(tmp_path / "points.yaml", VALID_POINTS)
    )
    empty_bt_dir = tmp_path / "behavior_trees"
    empty_bt_dir.mkdir()

    with pytest.raises(ConfigError, match="behavior tree does not exist"):
        load_mission_templates(
            write(tmp_path / "missions.yaml", VALID_MISSIONS),
            points,
            empty_bt_dir,
        )


@pytest.mark.parametrize(
    "nav_bt",
    ["../outside.xml", "/tmp/outside.xml", "nested/tree.xml"],
)
def test_rejects_behavior_tree_path_escape(
    tmp_path: Path, nav_bt: str
) -> None:
    points = load_inspection_points(
        write(tmp_path / "points.yaml", VALID_POINTS)
    )
    missions = VALID_MISSIONS.replace("inspection_nav_to_pose.xml", nav_bt)

    with pytest.raises(ConfigError, match="nav_bt"):
        load_mission_templates(
            write(tmp_path / "missions.yaml", missions),
            points,
            make_bt_dir(tmp_path),
        )


def test_yaml_is_loaded_safely(tmp_path: Path) -> None:
    malicious = "!!python/object/apply:builtins.eval ['40 + 2']\n"

    with pytest.raises(ConfigError, match="invalid YAML"):
        load_inspection_points(write(tmp_path / "points.yaml", malicious))


def test_repository_defaults_define_six_point_patrol_and_blocked_demo(
) -> None:
    package_root = Path(__file__).parents[1]
    config = load_configuration(
        package_root / "config" / "inspection_points.yaml",
        package_root / "config" / "mission_templates.yaml",
        package_root / "behavior_trees",
    )

    night_patrol = config.get_mission("night_patrol")
    blocked_demo = config.get_mission("blocked_optional_demo")
    assert len(night_patrol.point_ids) == 6
    demo_points = config.resolve_points(blocked_demo)
    assert any(
        point.allow_skip
        and (abs(point.x) > 50 or abs(point.y) > 50)
        for point in demo_points
    )
