from __future__ import annotations

from types import SimpleNamespace

import pytest

from property_inspection.inspection_executor import SimulatedInspectionExecutor


@pytest.mark.parametrize(
    ("point_type", "expected_message"),
    [
        ("security", "模拟安防巡检正常"),
        ("facility", "模拟拍照及设备状态检查正常"),
        ("environment", "模拟环境卫生检查正常"),
        ("dock", "到达回充点，任务收尾"),
    ],
)
def test_returns_deterministic_success_for_each_point_type(
    point_type: str, expected_message: str
) -> None:
    point = SimpleNamespace(point_type=point_type, stay_time=0.0)
    executor = SimulatedInspectionExecutor(sleep=lambda _: None)

    first = executor.execute(point)
    second = executor.execute(point)

    assert first == second
    assert first.success is True
    assert first.message == expected_message


def test_honors_configured_stay_time_without_creating_real_artifacts() -> None:
    delays: list[float] = []
    point = SimpleNamespace(point_type="facility", stay_time=2.5)

    outcome = SimulatedInspectionExecutor(sleep=delays.append).execute(point)

    assert delays == [2.5]
    assert outcome.message == "模拟拍照及设备状态检查正常"
    assert not hasattr(outcome, "image_path")


def test_rejects_unknown_point_type() -> None:
    executor = SimulatedInspectionExecutor(sleep=lambda _: None)

    with pytest.raises(ValueError, match="unsupported inspection point type"):
        executor.execute(SimpleNamespace(point_type="unknown", stay_time=0.0))
