import importlib.util
from pathlib import Path

from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
)
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


PACKAGE_ROOT = Path(__file__).parents[1]
LAUNCH_PATH = PACKAGE_ROOT / "launch" / "inspection_sim.launch.py"


def _load_launch_module():
    spec = importlib.util.spec_from_file_location(
        "inspection_sim_launch", LAUNCH_PATH
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _source_path(include):
    source = include.launch_description_source
    # Humble's public location requires loading the external launch file;
    # this controlled white-box access avoids those side effects.
    return _substitution_text(source._LaunchDescriptionSource__location)


def _substitution_text(parts):
    if isinstance(parts, str):
        return parts
    return "".join(
        part.text if hasattr(part, "text") else str(part)
        for part in parts
    )


def _launch_configuration_name(value):
    assert isinstance(value, LaunchConfiguration)
    return _substitution_text(value.variable_name)


def _typed_float_launch_configuration_name(value):
    assert isinstance(value, ParameterValue)
    assert value.value_type is float
    substitutions = value.value
    assert len(substitutions) == 1
    return _launch_configuration_name(substitutions[0])


def _mission_parameters(mission):
    # Humble exposes no suitable public accessor for Node parameter structure;
    # keep this controlled white-box boundary centralized here.
    return {
        _substitution_text(name): value
        for name, value in mission._Node__parameters[0].items()
    }


def _node_arguments(node):
    # Humble exposes no public accessor for Node argument structure;
    # keep this controlled white-box boundary centralized here.
    return node._Node__arguments


def _launch_entities(monkeypatch):
    monkeypatch.setenv("ROS_LOG_DIR", "/tmp/property_inspection_launch_test")
    module = _load_launch_module()
    shares = {
        "property_inspection": str(PACKAGE_ROOT),
        "gazebo_ros": "/opt/ros/humble/share/gazebo_ros",
        "nav2_bringup": "/opt/ros/humble/share/nav2_bringup",
        "turtlebot3_gazebo": "/tmp/turtlebot3_gazebo",
        "turtlebot3_navigation2": "/tmp/turtlebot3_navigation2",
    }
    monkeypatch.setattr(
        module, "get_package_share_directory", shares.__getitem__
    )
    return list(module.generate_launch_description().entities)


def test_launch_declares_public_interface_and_burger_environment(monkeypatch):
    entities = _launch_entities(monkeypatch)
    declared = {
        entity.name: _substitution_text(entity.default_value)
        for entity in entities
        if isinstance(entity, DeclareLaunchArgument)
    }
    assert declared["mission_id"] == "night_patrol"
    assert declared["gui"] == "true"
    assert declared["pause"] == "false"
    assert declared["rviz"] == "true"
    assert declared["use_sim_time"] == "true"
    assert declared["navigation_timeout_sec"] == "120.0"
    assert "report_dir" in declared

    env = [
        entity
        for entity in entities
        if isinstance(entity, SetEnvironmentVariable)
    ]
    assert len(env) == 1
    assert _substitution_text(env[0].name) == "TURTLEBOT3_MODEL"
    assert _substitution_text(env[0].value) == "burger"


def test_launch_defaults_to_packaged_room3_world_and_long_map(monkeypatch):
    entities = _launch_entities(monkeypatch)
    declared = {
        entity.name: _substitution_text(entity.default_value)
        for entity in entities
        if isinstance(entity, DeclareLaunchArgument)
    }

    assert "world" in declared
    assert declared["world"].endswith(
        "property_inspection/worlds/room3.world"
    )
    assert declared["map"].endswith(
        "turtlebot3_navigation2/map/map.yaml"
    )


def test_launch_declares_independent_spawn_and_initial_pose_defaults(
    monkeypatch,
):
    entities = _launch_entities(monkeypatch)
    declared = {
        entity.name: _substitution_text(entity.default_value)
        for entity in entities
        if isinstance(entity, DeclareLaunchArgument)
    }

    expected_defaults = {
        "spawn_x": "-10.5",
        "spawn_y": "-1.0",
        "spawn_yaw": "0.0",
        "initial_pose_x": "3.0",
        "initial_pose_y": "-1.5",
        "initial_pose_yaw": "0.0",
    }
    assert {
        name: declared.get(name)
        for name in expected_defaults
    } == expected_defaults


def test_launch_wires_gazebo_nav2_rviz_and_mission_node(monkeypatch):
    entities = _launch_entities(monkeypatch)
    includes = [
        entity
        for entity in entities
        if isinstance(entity, IncludeLaunchDescription)
    ]
    include_paths = [_source_path(include) for include in includes]
    expected_launch_suffixes = {
        "gazebo_ros/launch/gzserver.launch.py",
        "gazebo_ros/launch/gzclient.launch.py",
        "turtlebot3_gazebo/launch/robot_state_publisher.launch.py",
        "nav2_bringup/launch/bringup_launch.py",
    }
    for suffix in expected_launch_suffixes:
        assert any(path.endswith(suffix) for path in include_paths)

    gzclient = next(
        item
        for item in includes
        if _source_path(item).endswith("gzclient.launch.py")
    )
    assert isinstance(gzclient.condition, IfCondition)
    nav2 = next(
        item
        for item in includes
        if _source_path(item).endswith("bringup_launch.py")
    )
    nav2_args = dict(nav2.launch_arguments)
    assert nav2_args["slam"] == "False"
    assert nav2_args["use_composition"] == "True"

    nodes = [entity for entity in entities if isinstance(entity, Node)]
    rviz = next(node for node in nodes if node.node_package == "rviz2")
    assert isinstance(rviz.condition, IfCondition)
    assert any(
        node.node_package == "gazebo_ros"
        and node.node_executable == "spawn_entity.py"
        for node in nodes
    )

    assert any(
        node.node_package == "property_inspection"
        and node.node_executable == "mission_manager"
        for node in nodes
    )


def test_gzserver_world_comes_from_public_launch_configuration(monkeypatch):
    entities = _launch_entities(monkeypatch)
    gzserver = next(
        entity
        for entity in entities
        if isinstance(entity, IncludeLaunchDescription)
        and _source_path(entity).endswith("gzserver.launch.py")
    )

    gzserver_args = dict(gzserver.launch_arguments)
    assert _launch_configuration_name(gzserver_args["world"]) == "world"
    assert _launch_configuration_name(gzserver_args["pause"]) == "pause"


def test_spawn_pose_uses_public_launch_configurations(monkeypatch):
    entities = _launch_entities(monkeypatch)
    spawn = next(
        entity
        for entity in entities
        if isinstance(entity, Node)
        and entity.node_package == "gazebo_ros"
        and entity.node_executable == "spawn_entity.py"
    )

    spawn_args = _node_arguments(spawn)
    assert spawn_args[:5] == [
        "-entity",
        "burger",
        "-file",
        "/tmp/turtlebot3_gazebo/models/turtlebot3_burger/model.sdf",
        "-x",
    ]
    assert _launch_configuration_name(spawn_args[5]) == "spawn_x"
    assert spawn_args[6] == "-y"
    assert _launch_configuration_name(spawn_args[7]) == "spawn_y"
    assert spawn_args[8:11] == ["-z", "0.01", "-Y"]
    assert _launch_configuration_name(spawn_args[11]) == "spawn_yaw"


def test_mission_manager_receives_initial_pose_launch_configurations(
    monkeypatch,
):
    entities = _launch_entities(monkeypatch)
    mission = next(
        entity
        for entity in entities
        if isinstance(entity, Node)
        and entity.node_package == "property_inspection"
        and entity.node_executable == "mission_manager"
    )

    mission_params = _mission_parameters(mission)
    assert set(mission_params) == {
        "use_sim_time",
        "mission_id",
        "report_dir",
        "navigation_timeout_sec",
        "initial_pose_x",
        "initial_pose_y",
        "initial_pose_yaw",
        "points_file",
        "missions_file",
    }
    for name in ("initial_pose_x", "initial_pose_y", "initial_pose_yaw"):
        assert _typed_float_launch_configuration_name(
            mission_params[name]
        ) == name
