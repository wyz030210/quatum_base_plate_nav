import math
import time
from types import SimpleNamespace

import pytest
from action_msgs.srv import CancelGoal
from builtin_interfaces.msg import Time
from nav2_msgs.srv import ManageLifecycleNodes
from nav2_simple_commander.robot_navigator import TaskResult

from property_inspection.models import NavigationResult, Pose2D
from property_inspection.navigator import BasicNavigatorAdapter


class FakeClock:
    class _Now:
        @staticmethod
        def to_msg():
            return Time()

    def now(self):
        return self._Now()


class FakeBasicNavigator:
    def __init__(self, results=None, accepted=True):
        self.results = list(results or [True])
        self.accepted = accepted
        self.goals = []
        self.canceled = False
        self.initial_pose = None
        self.waited = False
        self.goal_handle = None
        self.result_future = None
        self.nav_to_pose_client = FakeActionClient(self, accepted=accepted)
        self.cancel_goal_client = FakeCancelGoalClient()
        self.lifecycle_client = FakeLifecycleClient()

    def get_clock(self):
        return FakeClock()

    def setInitialPose(self, pose):
        self.initial_pose = pose

    def waitUntilNav2Active(self):
        self.waited = True

    def goToPose(self, pose, behavior_tree=''):
        self.goals.append((pose, behavior_tree))
        return self.accepted

    def isTaskComplete(self):
        if len(self.results) > 1:
            return self.results.pop(0)
        return self.results[0]

    def getResult(self):
        return TaskResult.SUCCEEDED

    def cancelTask(self):
        self.canceled = True

    def create_client(self, _service_type, service_name):
        if service_name == '/navigate_to_pose/_action/cancel_goal':
            return self.cancel_goal_client
        assert service_name == '/lifecycle_manager_navigation/manage_nodes'
        return self.lifecycle_client


class PendingFuture:
    def __init__(self, done, value=None):
        self._done = done
        self._value = value

    def done(self):
        return self._done

    def result(self):
        return self._value


class CancelGoalHandle:
    def __init__(self, navigator, cancel_done=True, accepted=True):
        self.navigator = navigator
        self.cancel_done = cancel_done
        self.accepted = accepted
        self.cancel_calls = 0

    def get_result_async(self):
        return object()

    def cancel_goal_async(self):
        self.cancel_calls += 1
        self.navigator.canceled = True
        if self.cancel_done:
            self.navigator.results = [True]
        return PendingFuture(self.cancel_done)


class FakeCancelGoalClient:
    def __init__(
        self,
        available=True,
        response_done=True,
        return_code=CancelGoal.Response.ERROR_UNKNOWN_GOAL_ID,
    ):
        self.available = available
        self.response_done = response_done
        self.return_code = return_code
        self.calls = 0
        self.requested_uuids = []

    def wait_for_service(self, timeout_sec):
        return self.available

    def call_async(self, request):
        self.requested_uuids.append(list(request.goal_info.goal_id.uuid))
        self.calls += 1
        response = SimpleNamespace(
            return_code=self.return_code,
            goals_canceling=[],
        )
        return PendingFuture(self.response_done, response)


class FakeLifecycleClient:
    def __init__(self, available=True, response_done=True, success=True):
        self.available = available
        self.response_done = response_done
        self.success = success
        self.calls = 0

    def wait_for_service(self, timeout_sec):
        return self.available

    def call_async(self, request):
        assert request.command == ManageLifecycleNodes.Request.PAUSE
        self.calls += 1
        return PendingFuture(
            self.response_done,
            SimpleNamespace(success=self.success),
        )


class FakeActionClient:
    def __init__(
        self,
        navigator,
        accepted=True,
        available=True,
        response_done=True,
        cancel_done=True,
    ):
        self.navigator = navigator
        self.accepted = accepted
        self.available = available
        self.response_done = response_done
        self.cancel_done = cancel_done

    def wait_for_server(self, timeout_sec):
        return self.available

    def send_goal_async(self, goal, goal_uuid=None):
        self.navigator.goals.append((goal.pose, goal.behavior_tree))
        self.navigator.sent_goal_uuid = goal_uuid
        handle = CancelGoalHandle(
            self.navigator,
            cancel_done=self.cancel_done,
            accepted=self.accepted,
        )
        return PendingFuture(self.response_done, handle)


def test_navigate_forwards_absolute_behavior_tree_and_pose():
    fake = FakeBasicNavigator()
    adapter = BasicNavigatorAdapter(fake, navigation_timeout_sec=10.0)

    result = adapter.navigate_to(Pose2D(1.2, -0.4, math.pi / 2), '/tmp/tree.xml')

    assert result is NavigationResult.SUCCESS
    goal, tree = fake.goals[0]
    assert tree == '/tmp/tree.xml'
    assert goal.header.frame_id == 'map'
    assert goal.pose.position.x == 1.2
    assert goal.pose.position.y == -0.4
    assert goal.pose.orientation.z == pytest.approx(math.sin(math.pi / 4))
    assert goal.pose.orientation.w == pytest.approx(math.cos(math.pi / 4))


def test_rejected_goal_is_failed():
    fake = FakeBasicNavigator(accepted=False)
    adapter = BasicNavigatorAdapter(fake)

    assert adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml') is NavigationResult.FAILED


def test_timeout_cancels_without_retrying():
    fake = FakeBasicNavigator(results=[False])
    times = iter([0.0, 0.0, 2.0, 2.0])
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        monotonic=lambda: next(times),
        sleep=lambda _seconds: None,
    )

    result = adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml')

    assert result is NavigationResult.TIMEOUT
    assert fake.canceled is True
    assert len(fake.goals) == 1


def test_initial_pose_and_active_wait_are_delegated():
    fake = FakeBasicNavigator()
    adapter = BasicNavigatorAdapter(fake)

    adapter.set_initial_pose(Pose2D(-2.0, -0.5, 0.0))
    adapter.wait_until_active()

    assert fake.initial_pose.header.frame_id == 'map'
    assert fake.waited is True


@pytest.mark.parametrize('timeout', [0.0, -1.0, math.nan, math.inf])
def test_invalid_navigation_timeout_is_rejected(timeout):
    with pytest.raises(ValueError):
        BasicNavigatorAdapter(FakeBasicNavigator(), navigation_timeout_sec=timeout)


@pytest.mark.parametrize('poll_interval', [0.0, -0.1, math.nan, math.inf])
def test_invalid_poll_interval_is_rejected(poll_interval):
    with pytest.raises(ValueError):
        BasicNavigatorAdapter(FakeBasicNavigator(), poll_interval_sec=poll_interval)


def test_nav2_activation_wait_has_a_wall_clock_deadline():
    class NeverActiveNavigator(FakeBasicNavigator):
        def waitUntilNav2Active(self):
            time.sleep(1.0)

    adapter = BasicNavigatorAdapter(
        NeverActiveNavigator(), activation_timeout_sec=0.01
    )

    with pytest.raises(TimeoutError, match='Nav2 activation'):
        adapter.wait_until_active()


def test_unresponsive_cancel_aborts_in_bounded_time_without_next_goal():
    fake = FakeBasicNavigator(results=[False])
    fake.nav_to_pose_client.cancel_done = False
    times = iter([0.0, 0.0, 2.0])
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        cancel_timeout_sec=0.01,
        monotonic=lambda: next(times),
        sleep=lambda _seconds: None,
        spin_until_future_complete=lambda *_args, **_kwargs: None,
    )

    with pytest.raises(TimeoutError, match='cancel'):
        adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml')

    assert len(fake.goals) == 1


def test_unavailable_action_server_is_bounded_by_navigation_timeout():
    fake = FakeBasicNavigator()
    fake.nav_to_pose_client.available = False
    times = iter([0.0, 0.0, 2.0])
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        monotonic=lambda: next(times),
        sleep=lambda _seconds: None,
    )

    with pytest.raises(TimeoutError, match='action server'):
        adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml')

    assert fake.goals == []


def test_pending_goal_response_is_bounded_by_navigation_timeout():
    fake = FakeBasicNavigator()
    fake.nav_to_pose_client.response_done = False
    times = iter([0.0, 0.0, 0.0])
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        monotonic=lambda: next(times),
        spin_until_future_complete=lambda *_args, **_kwargs: None,
    )

    with pytest.raises(TimeoutError, match='goal response'):
        adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml')


def test_cancel_pending_first_goal_targets_uuid_then_pauses_nav2():
    fake = FakeBasicNavigator()
    fake.nav_to_pose_client.response_done = False
    times = iter([0.0, 0.0, 0.0])
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        monotonic=lambda: next(times),
        spin_until_future_complete=lambda *_args, **_kwargs: None,
    )

    with pytest.raises(TimeoutError, match='goal response'):
        adapter.navigate_to(Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml')

    assert adapter.cancel() is True
    sent_uuid = list(fake.sent_goal_uuid.uuid)
    assert sent_uuid != [0] * 16
    assert fake.cancel_goal_client.requested_uuids == [sent_uuid]
    assert fake.lifecycle_client.calls == 1


def test_pending_next_goal_never_cancels_previous_completed_handle():
    fake = FakeBasicNavigator()
    adapter = BasicNavigatorAdapter(
        fake,
        navigation_timeout_sec=1.0,
        monotonic=lambda: 0.0,
        spin_until_future_complete=lambda *_args, **_kwargs: None,
    )
    assert adapter.navigate_to(
        Pose2D(0.0, 0.0, 0.0), '/tmp/tree.xml'
    ) is NavigationResult.SUCCESS
    previous_handle = fake.goal_handle
    fake.nav_to_pose_client.response_done = False

    with pytest.raises(TimeoutError, match='goal response'):
        adapter.navigate_to(Pose2D(1.0, 0.0, 0.0), '/tmp/tree.xml')

    assert fake.goal_handle is None
    assert adapter.cancel() is True
    assert previous_handle.cancel_calls == 0
    assert fake.cancel_goal_client.calls == 1
    assert fake.lifecycle_client.calls == 1
