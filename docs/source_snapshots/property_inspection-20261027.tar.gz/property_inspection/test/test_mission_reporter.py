from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

from property_inspection.mission_reporter import MissionReporter


POINT_RECORD = {
    "mission_id": "night_patrol",
    "mission_name": "Night patrol",
    "point_id": "gate_1",
    "point_name": "Gate",
    "point_type": "security",
    "start_time": "2026-06-20T04:30:01Z",
    "end_time": "2026-06-20T04:30:04Z",
    "duration_sec": 3.0,
    "navigation_result": "SUCCESS",
    "inspection_result": "SUCCESS",
    "status": "SUCCESS",
    "allow_skip": True,
    "message": "模拟安防巡检正常",
}


def make_clock(values: list[object]):
    iterator = iter(values)
    return lambda: next(iterator)


def test_start_creates_timestamped_run_directory_under_injected_root(
    tmp_path: Path,
) -> None:
    reporter = MissionReporter(
        tmp_path,
        utc_now=lambda: datetime(2026, 6, 20, 4, 30, tzinfo=timezone.utc),
        monotonic=lambda: 10.0,
    )
    mission = SimpleNamespace(
        mission_id="night_patrol", name="Night patrol", point_ids=("gate_1",)
    )

    run_dir = reporter.start(mission)

    assert run_dir == tmp_path / "mission_20260620T043000Z_night_patrol"
    assert reporter.run_dir == run_dir
    assert run_dir.is_dir()
    assert (run_dir / "point_records.jsonl").is_file()


def test_start_rejects_unsafe_mission_id(tmp_path: Path) -> None:
    reporter = MissionReporter(
        tmp_path,
        utc_now=lambda: datetime(2026, 6, 20, tzinfo=timezone.utc),
        monotonic=lambda: 10.0,
    )

    with pytest.raises(ValueError, match="mission_id"):
        reporter.start(SimpleNamespace(mission_id="../../../escape", name="x"))


def test_same_mission_started_in_same_second_gets_unique_directory(
    tmp_path: Path,
) -> None:
    def now():
        return datetime(2026, 6, 20, 4, 30, tzinfo=timezone.utc)

    mission = SimpleNamespace(mission_id="night_patrol", name="Night patrol")
    first = MissionReporter(tmp_path, utc_now=now, monotonic=lambda: 1.0)
    second = MissionReporter(tmp_path, utc_now=now, monotonic=lambda: 1.0)

    first_dir = first.start(mission)
    second_dir = second.start(mission)

    assert first_dir != second_dir
    assert second_dir.parent == tmp_path


def test_record_point_flushes_projected_schema_before_finalize(tmp_path: Path) -> None:
    reporter = MissionReporter(
        tmp_path,
        utc_now=lambda: datetime(2026, 6, 20, 4, 30, tzinfo=timezone.utc),
        monotonic=lambda: 10.0,
    )
    reporter.start(SimpleNamespace(mission_id="night_patrol", name="Night patrol"))

    reporter.record_point(
        {
            **POINT_RECORD,
            "planned_path_length": 9.1,
            "actual_path_length": 8.4,
            "odom_distance": 8.5,
            "trajectory_file": "trajectory.csv",
            "path_compare_result": "same",
        }
    )

    line = (reporter.run_dir / "point_records.jsonl").read_text(
        encoding="utf-8"
    )
    stored = json.loads(line)
    assert stored == POINT_RECORD


def test_finalize_atomically_writes_summary_json_and_point_csv(tmp_path: Path) -> None:
    utc_now = make_clock(
        [
            datetime(2026, 6, 20, 4, 30, tzinfo=timezone.utc),
            datetime(2026, 6, 20, 4, 31, tzinfo=timezone.utc),
        ]
    )
    monotonic = make_clock([100.0, 160.25])
    reporter = MissionReporter(tmp_path, utc_now=utc_now, monotonic=monotonic)
    mission = SimpleNamespace(
        mission_id="night_patrol",
        name="Night patrol",
        point_ids=("gate_1", "trash_bin_1", "fire_box_1"),
    )
    reporter.start(mission)
    reporter.record_point(POINT_RECORD)
    reporter.record_point(
        {
            **POINT_RECORD,
            "point_id": "trash_bin_1",
            "point_name": "Trash bin",
            "status": "SKIPPED",
            "navigation_result": "FAILED",
            "inspection_result": "NOT_RUN",
            "message": "navigation failed",
        }
    )
    reporter.record_point(
        {
            **POINT_RECORD,
            "point_id": "fire_box_1",
            "point_name": "Fire box",
            "status": "FAILED",
            "navigation_result": "FAILED",
            "inspection_result": "NOT_RUN",
            "allow_skip": False,
            "message": "required point failed",
        }
    )

    summary_path = reporter.finalize("ABORTED", message="required point failed")

    assert summary_path == reporter.run_dir / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    assert summary == {
        "mission_id": "night_patrol",
        "mission_name": "Night patrol",
        "final_status": "ABORTED",
        "start_time": "2026-06-20T04:30:00Z",
        "end_time": "2026-06-20T04:31:00Z",
        "duration_sec": 60.25,
        "total_points": 3,
        "success_count": 1,
        "failed_count": 1,
        "skipped_count": 1,
        "last_processed_point": "fire_box_1",
        "report_dir": str(reporter.run_dir.resolve()),
        "message": "required point failed",
    }
    with (reporter.run_dir / "summary.csv").open(
        newline="", encoding="utf-8"
    ) as stream:
        rows = list(csv.DictReader(stream))
    assert [row["point_id"] for row in rows] == [
        "gate_1",
        "trash_bin_1",
        "fire_box_1",
    ]
    assert rows[0]["allow_skip"] == "True"
    assert not list(reporter.run_dir.glob(".*.tmp"))


def test_requires_start_and_allows_each_lifecycle_operation_only_once(
    tmp_path: Path,
) -> None:
    reporter = MissionReporter(
        tmp_path,
        utc_now=lambda: datetime(2026, 6, 20, tzinfo=timezone.utc),
        monotonic=make_clock([0.0, 1.0]),
    )

    with pytest.raises(RuntimeError, match="not started"):
        reporter.record_point(POINT_RECORD)
    reporter.start(SimpleNamespace(mission_id="night_patrol", name="Night patrol"))
    with pytest.raises(RuntimeError, match="already started"):
        reporter.start(SimpleNamespace(mission_id="night_patrol", name="Night patrol"))
    reporter.finalize("FINISHED")
    with pytest.raises(RuntimeError, match="already finalized"):
        reporter.record_point(POINT_RECORD)
    with pytest.raises(RuntimeError, match="already finalized"):
        reporter.finalize("FINISHED")


def test_missing_required_point_field_is_rejected(tmp_path: Path) -> None:
    reporter = MissionReporter(
        tmp_path,
        utc_now=lambda: datetime(2026, 6, 20, tzinfo=timezone.utc),
        monotonic=make_clock([0.0]),
    )
    reporter.start(SimpleNamespace(mission_id="mission", name="Mission"))
    incomplete = dict(POINT_RECORD)
    incomplete.pop("point_id")

    with pytest.raises(ValueError, match="point_id"):
        reporter.record_point(incomplete)
