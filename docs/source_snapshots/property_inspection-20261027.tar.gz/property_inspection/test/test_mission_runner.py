from pathlib import Path

from property_inspection.mission_runner import MissionRunner
from property_inspection.models import (
    InspectionOutcome,
    InspectionPoint,
    MissionState,
    MissionTemplate,
    NavigationResult,
    PointStatus,
    PointType,
    Pose2D,
)


def point(point_id, allow_skip):
    return InspectionPoint(
        point_id,
        point_id,
        PointType.SECURITY,
        Pose2D(0.0, 0.0, 0.0),
        0.0,
        allow_skip,
    )


class FakeNavigator:
    def __init__(self, results):
        self.results = iter(results)
        self.calls = []

    def navigate_to(self, pose, behavior_tree):
        self.calls.append((pose, behavior_tree))
        return next(self.results)


class FakeInspector:
    def __init__(self):
        self.calls = []

    def execute(self, inspection_point):
        self.calls.append(inspection_point.point_id)
        return InspectionOutcome(True, 'normal')


class FakeReporter:
    def __init__(self):
        self.records = []
        self.finalized = None

    def start(self, mission):
        self.mission = mission
        return Path('/tmp/run')

    def record_point(self, record):
        self.records.append(record)

    def finalize(self, mission_state, message=''):
        self.finalized = (mission_state, message)
        return Path('/tmp/run/summary.json')


def mission(*ids):
    return MissionTemplate('night_patrol', 'Night Patrol', ids, '/abs/inspection.xml', True)


def test_all_success_visits_each_point_once_and_finishes():
    points = {'p1': point('p1', True), 'p2': point('p2', False)}
    navigator = FakeNavigator([NavigationResult.SUCCESS, NavigationResult.SUCCESS])
    inspector = FakeInspector()
    reporter = FakeReporter()
    states = []
    runner = MissionRunner(navigator, inspector, reporter, state_callback=states.append)

    result = runner.run(mission('p1', 'p2'), points)

    assert result.state is MissionState.FINISHED
    assert result.succeeded == 2
    assert len(navigator.calls) == 2
    assert [call[1] for call in navigator.calls] == ['/abs/inspection.xml'] * 2
    assert inspector.calls == ['p1', 'p2']
    assert reporter.finalized[0] is MissionState.FINISHED
    assert states == [
        MissionState.LOAD_MISSION,
        MissionState.NAVIGATING,
        MissionState.INSPECTING,
        MissionState.LOGGING,
        MissionState.NAVIGATING,
        MissionState.INSPECTING,
        MissionState.LOGGING,
        MissionState.FINISHED,
    ]


def test_optional_navigation_failure_is_skipped_and_next_point_runs():
    points = {'optional': point('optional', True), 'next': point('next', False)}
    navigator = FakeNavigator([NavigationResult.FAILED, NavigationResult.SUCCESS])
    inspector = FakeInspector()
    reporter = FakeReporter()

    result = MissionRunner(navigator, inspector, reporter).run(mission('optional', 'next'), points)

    assert result.state is MissionState.FINISHED
    assert result.skipped == 1
    assert result.succeeded == 1
    assert inspector.calls == ['next']
    assert reporter.records[0]['status'] == PointStatus.SKIPPED.value


def test_required_navigation_failure_aborts_without_visiting_next_point():
    points = {'required': point('required', False), 'next': point('next', True)}
    navigator = FakeNavigator([NavigationResult.TIMEOUT])
    inspector = FakeInspector()
    reporter = FakeReporter()

    result = MissionRunner(navigator, inspector, reporter).run(mission('required', 'next'), points)

    assert result.state is MissionState.ABORTED
    assert result.failed == 1
    assert len(navigator.calls) == 1
    assert inspector.calls == []
    assert reporter.records[0]['status'] == PointStatus.FAILED.value
    assert reporter.finalized[0] is MissionState.ABORTED


def test_required_failure_cannot_be_overridden_by_mission_template():
    points = {'required': point('required', False)}
    non_stopping_template = MissionTemplate(
        'mission', 'Mission', ('required',), '/abs/tree.xml', False
    )

    result = MissionRunner(
        FakeNavigator([NavigationResult.FAILED]),
        FakeInspector(),
        FakeReporter(),
    ).run(non_stopping_template, points)

    assert result.state is MissionState.ABORTED
