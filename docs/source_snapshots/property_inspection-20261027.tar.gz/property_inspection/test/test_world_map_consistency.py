import math
from pathlib import Path
import xml.etree.ElementTree as ET

import yaml


PACKAGE_ROOT = Path(__file__).parents[1]
WORKSPACE_SRC = PACKAGE_ROOT.parent
WORLD_PATH = PACKAGE_ROOT / "worlds" / "room3.world"
MAP_DIR = WORKSPACE_SRC / "turtlebot3-humble" / "turtlebot3_navigation2" / "map"
WORLD_TO_MAP_X = 13.5
WORLD_TO_MAP_Y = -0.5


def _read_pgm(path):
    data = path.read_bytes()
    tokens = []
    index = 0
    while len(tokens) < 4:
        while data[index:index + 1].isspace():
            index += 1
        if data[index:index + 1] == b"#":
            index = data.index(b"\n", index) + 1
            continue
        end = index
        while not data[end:end + 1].isspace():
            end += 1
        tokens.append(data[index:end])
        index = end
    magic, width, height, maximum = tokens
    assert magic == b"P5"
    assert int(maximum) == 255
    index += 2 if data[index:index + 2] == b"\r\n" else 1
    return int(width), int(height), data[index:]


def _pixel_at(x, y, width, height, pixels, resolution, origin):
    column = math.floor((x - origin[0]) / resolution)
    row_from_bottom = math.floor((y - origin[1]) / resolution)
    row = height - 1 - row_from_bottom
    assert 0 <= column < width
    assert 0 <= row < height
    return pixels[row * width + column]


def test_room3_fixed_boxes_are_present_in_static_map():
    config = yaml.safe_load((MAP_DIR / "map.yaml").read_text(encoding="utf-8"))
    width, height, pixels = _read_pgm(MAP_DIR / config["image"])
    resolution = float(config["resolution"])
    origin = config["origin"]
    world = ET.parse(WORLD_PATH).getroot()
    checked = []

    for model in world.findall("./world/model"):
        if not model.attrib.get("name", "").startswith("unit_box"):
            continue
        pose = [float(value) for value in model.findtext("pose").split()]
        size = [
            float(value)
            for value in model.findtext("./link/collision/geometry/box/size").split()
        ]
        for x_fraction in (-0.3, 0.0, 0.3):
            for y_fraction in (-0.3, 0.0, 0.3):
                x = pose[0] + WORLD_TO_MAP_X + x_fraction * size[0]
                y = pose[1] + WORLD_TO_MAP_Y + y_fraction * size[1]
                assert _pixel_at(
                    x, y, width, height, pixels, resolution, origin
                ) != 254, (model.attrib["name"], x, y)
        checked.append(model.attrib["name"])

    assert len(checked) == 10
