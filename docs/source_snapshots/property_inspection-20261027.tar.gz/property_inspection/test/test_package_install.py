from pathlib import Path

import yaml


PACKAGE_ROOT = Path(__file__).parents[1]


def test_setup_installs_runtime_assets_and_console_entrypoint():
    setup_text = (PACKAGE_ROOT / 'setup.py').read_text(encoding='utf-8')

    assert (PACKAGE_ROOT / 'worlds' / 'room3.world').is_file()
    assert 'config/*.yaml' in setup_text
    assert 'behavior_trees/*.xml' in setup_text
    assert 'launch/*.launch.py' in setup_text
    assert 'rviz/*.rviz' in setup_text
    assert 'worlds/*.world' in setup_text
    assert (
        'mission_manager = property_inspection.mission_manager_node:main'
        in setup_text
    )
    assert 'coverage_task_node = property_inspection.coverage_task_node:main' in setup_text
    assert 'coverage_cli = property_inspection.coverage_cli:main' in setup_text


def test_coverage_runtime_assets_exist_and_dependencies_are_declared():
    manifest = (PACKAGE_ROOT / 'package.xml').read_text(encoding='utf-8')

    for relative_path in (
        'config/coverage_params.yaml',
        'launch/coverage_sim.launch.py',
        'rviz/coverage.rviz',
    ):
        assert (PACKAGE_ROOT / relative_path).is_file()
    for dependency in (
        'nav2_lifecycle_manager',
        'nav2_regulated_pure_pursuit_controller',
        'opennav_coverage',
        'opennav_coverage_msgs',
        'python3-shapely',
        'std_srvs',
        'tf2_ros',
        'visualization_msgs',
    ):
        assert f'<exec_depend>{dependency}</exec_depend>' in manifest


def test_package_has_no_custom_action_or_patrol_dependency():
    manifest = (PACKAGE_ROOT / 'package.xml').read_text(encoding='utf-8')

    assert 'inspection_interfaces' not in manifest
    assert 'turtlebot3_msgs' not in manifest
    assert '<action' not in manifest


def test_sim_params_matches_default_initial_pose():
    sim_params = yaml.safe_load(
        (PACKAGE_ROOT / 'config' / 'sim_params.yaml').read_text(
            encoding='utf-8'
        )
    )
    params = sim_params['mission_manager']['ros__parameters']

    assert {
        'initial_pose_x': params['initial_pose_x'],
        'initial_pose_y': params['initial_pose_y'],
        'initial_pose_yaw': params['initial_pose_yaw'],
    } == {
        'initial_pose_x': 3.0,
        'initial_pose_y': -1.5,
        'initial_pose_yaw': 0.0,
    }


def test_manifest_declares_every_direct_launch_dependency():
    manifest = (PACKAGE_ROOT / 'package.xml').read_text(encoding='utf-8')

    for dependency in (
        'gazebo_ros',
        'nav2_common',
        'rviz2',
        'turtlebot3_navigation2',
    ):
        assert f'<exec_depend>{dependency}</exec_depend>' in manifest
