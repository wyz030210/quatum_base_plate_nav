from pathlib import Path
import xml.etree.ElementTree as ET

import yaml


PACKAGE_ROOT = Path(__file__).parents[1]
BT_PATH = PACKAGE_ROOT / "behavior_trees" / "inspection_nav_to_pose.xml"
PARAMS_PATH = PACKAGE_ROOT / "config" / "nav2_params_inspection.yaml"


def test_behavior_tree_has_bounded_ordered_local_recoveries():
    root = ET.parse(BT_PATH).getroot()

    outer_recovery = root.find("./BehaviorTree/RecoveryNode")
    assert outer_recovery is not None
    assert outer_recovery.attrib["number_of_retries"] == "4"

    rate_controller = outer_recovery.find("./PipelineSequence/RateController")
    assert rate_controller is not None
    assert rate_controller.attrib["hz"] == "1.0"

    recovery_actions = outer_recovery.find("./ReactiveFallback/RoundRobin")
    assert recovery_actions is not None
    assert [child.tag for child in recovery_actions] == [
        "ClearEntireCostmap",
        "Wait",
        "BackUp",
        "Spin",
    ]

    clear, wait, backup, spin = list(recovery_actions)
    assert clear.attrib["service_name"] == (
        "local_costmap/clear_entirely_local_costmap"
    )
    assert wait.attrib["wait_duration"] == "3"
    assert backup.attrib["backup_dist"] == "0.30"
    assert backup.attrib["backup_speed"] == "0.05"
    assert spin.attrib["spin_dist"] == "0.785"

    all_clear_services = {
        node.attrib["service_name"]
        for node in root.iter("ClearEntireCostmap")
    }
    assert all_clear_services == {"local_costmap/clear_entirely_local_costmap"}


def test_nav2_parameters_are_complete_and_humble_compatible():
    params = yaml.safe_load(PARAMS_PATH.read_text(encoding="utf-8"))

    required_servers = {
        "amcl",
        "bt_navigator",
        "controller_server",
        "local_costmap",
        "global_costmap",
        "map_server",
        "planner_server",
        "smoother_server",
        "behavior_server",
        "waypoint_follower",
        "velocity_smoother",
    }
    assert required_servers <= params.keys()
    assert "recoveries_server" not in params

    bt_params = params["bt_navigator"]["ros__parameters"]
    assert bt_params["use_sim_time"] is True
    assert bt_params["default_nav_to_pose_bt_xml"] == (
        "inspection_nav_to_pose.xml"
    )

    controller = params["controller_server"]["ros__parameters"]
    assert controller["use_sim_time"] is True
    assert controller["progress_checker"]["required_movement_radius"] == 0.15
    assert controller["progress_checker"]["movement_time_allowance"] == 60.0
    assert controller["general_goal_checker"]["xy_goal_tolerance"] == 0.08
    assert controller["general_goal_checker"]["yaw_goal_tolerance"] == 0.15
    assert controller["CoverageFollowPath"]["max_robot_pose_search_dist"] == 1.0
    assert controller["FollowPath"]["max_vel_x"] == 0.22
    assert controller["FollowPath"]["max_speed_xy"] == 0.22

    behaviors = params["behavior_server"]["ros__parameters"]
    assert behaviors["use_sim_time"] is True
    assert behaviors["spin"]["plugin"] == "nav2_behaviors/Spin"
    assert behaviors["backup"]["plugin"] == "nav2_behaviors/BackUp"
    assert behaviors["wait"]["plugin"] == "nav2_behaviors/Wait"
    assert behaviors["max_rotational_vel"] <= 0.5

    for node_name, node in params.items():
        ros_params = node.get("ros__parameters")
        if ros_params is not None:
            assert ros_params.get("use_sim_time") is True, node_name
            continue
        for nested_name, nested_node in node.items():
            nested_params = nested_node.get("ros__parameters")
            if nested_params is not None:
                assert nested_params.get("use_sim_time") is True, (
                    f"{node_name}.{nested_name}"
                )
