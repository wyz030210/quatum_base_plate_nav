import importlib.util
from pathlib import Path

from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch_ros.actions import Node


PACKAGE_ROOT = Path(__file__).parents[1]
LAUNCH_PATH = PACKAGE_ROOT / "launch" / "coverage_sim.launch.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("coverage_sim_launch", LAUNCH_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_coverage_launch_wraps_sim_once_and_starts_only_coverage_extras(monkeypatch):
    monkeypatch.setenv("ROS_LOG_DIR", "/tmp/property_inspection_coverage_launch_test")
    module = _load_module()
    shares = {
        "property_inspection": str(PACKAGE_ROOT),
        "turtlebot3_navigation2": "/tmp/turtlebot3_navigation2",
    }
    monkeypatch.setattr(module, "get_package_share_directory", shares.__getitem__)
    entities = list(module.generate_launch_description().entities)
    simulation_groups = [item for item in entities if isinstance(item, GroupAction)]
    assert len(simulation_groups) == 1
    includes = [
        item
        for item in simulation_groups[0].get_sub_entities()
        if isinstance(item, IncludeLaunchDescription)
    ]
    nodes = [item for item in entities if isinstance(item, Node)]
    assert len(includes) == 1
    include_arguments = dict(includes[0].launch_arguments)
    assert include_arguments["start_mission"] == "false"
    assert include_arguments["rviz"] == "false"
    assert "pause" in include_arguments
    assert {(node.node_package, node.node_executable) for node in nodes} == {
        ("opennav_coverage", "opennav_coverage"),
        ("nav2_lifecycle_manager", "lifecycle_manager"),
        ("property_inspection", "coverage_task_node"),
        ("rviz2", "rviz2"),
    }


def test_coverage_launch_exposes_expected_public_arguments(monkeypatch):
    monkeypatch.setenv("ROS_LOG_DIR", "/tmp/property_inspection_coverage_launch_test")
    module = _load_module()
    shares = {
        "property_inspection": str(PACKAGE_ROOT),
        "turtlebot3_navigation2": "/tmp/turtlebot3_navigation2",
    }
    monkeypatch.setattr(module, "get_package_share_directory", shares.__getitem__)
    entities = list(module.generate_launch_description().entities)
    names = {
        item.name for item in entities if isinstance(item, DeclareLaunchArgument)
    }
    assert {
        "gui",
        "pause",
        "rviz",
        "use_sim_time",
        "world",
        "map",
        "params_file",
        "coverage_params_file",
        "spawn_x",
        "spawn_y",
        "spawn_yaw",
    } <= names
