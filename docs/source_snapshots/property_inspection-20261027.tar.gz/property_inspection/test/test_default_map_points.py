from collections import deque
import math
from pathlib import Path

import yaml


PACKAGE_ROOT = Path(__file__).parents[1]
MAP_DIR = (
    PACKAGE_ROOT.parent
    / 'turtlebot3-humble/turtlebot3_navigation2/map'
)
INITIAL_POSE = (3.0, -1.5)
ROBOT_RADIUS_METERS = 0.15
EXPECTED_POINT_POSES = {
    'gate_1': (4.0, -1.0, 0.0),
    'building_entrance_1': (7.0, -0.5, 0.0),
    'fire_box_1': (10.0, -1.5, 0.0),
    'electric_box_1': (12.0, 0.0, 0.0),
    'trash_bin_1': (17.0, -1.5, 0.0),
    'dock': (3.0, -1.5, 0.0),
}


def _read_pgm(path):
    data = path.read_bytes()
    tokens = []
    index = 0
    while len(tokens) < 4:
        while data[index:index + 1].isspace():
            index += 1
        if data[index:index + 1] == b'#':
            index = data.index(b'\n', index) + 1
            continue
        end = index
        while not data[end:end + 1].isspace():
            end += 1
        tokens.append(data[index:end])
        index = end
    magic, width, height, maximum = tokens
    assert magic == b'P5'
    assert int(maximum) == 255
    if data[index:index + 2] == b'\r\n':
        index += 2
    else:
        assert data[index:index + 1].isspace()
        index += 1
    width = int(width)
    height = int(height)
    pixels = data[index:]
    assert len(pixels) == width * height
    return width, height, pixels


def test_read_pgm_preserves_whitespace_valued_first_pixel(tmp_path):
    path = tmp_path / 'whitespace-first-pixel.pgm'
    raster = bytes((0x0A, 0xFE))
    path.write_bytes(b'P5\r\n2 1\r\n255\r\n' + raster)

    width, height, pixels = _read_pgm(path)

    assert (width, height) == (2, 1)
    assert pixels == raster


def test_world_clearance_accounts_for_pose_offset_within_cell():
    clearance = _world_clearance(
        x=0.9,
        y=0.5,
        non_free_cells=[(0, 1)],
        map_height=1,
        resolution=1.0,
        origin_x=0.0,
        origin_y=0.0,
    )

    assert math.isclose(clearance, 0.1)


def test_reachability_does_not_cross_disconnected_grid():
    pixels = bytes((
        254, 254, 0, 254, 254,
        254, 254, 0, 254, 254,
        254, 254, 0, 254, 254,
    ))

    reachable = _reachable_with_robot_clearance(
        width=5,
        height=3,
        pixels=pixels,
        resolution=1.0,
        robot_radius=ROBOT_RADIUS_METERS,
        start_index=5,
    )

    assert 9 not in reachable


def test_robot_clearance_includes_obstacle_cell_half_size():
    pixels = bytes((0, 254, 254, 254))

    reachable = _reachable_with_robot_clearance(
        width=4,
        height=1,
        pixels=pixels,
        resolution=0.05,
        robot_radius=0.15,
        start_index=3,
    )

    assert 3 not in reachable


def _world_clearance(
    x, y, non_free_cells, map_height, resolution, origin_x, origin_y
):
    clearances = []
    for row, column in non_free_cells:
        minimum_x = origin_x + column * resolution
        maximum_x = minimum_x + resolution
        row_from_bottom = map_height - 1 - row
        minimum_y = origin_y + row_from_bottom * resolution
        maximum_y = minimum_y + resolution
        delta_x = max(minimum_x - x, 0.0, x - maximum_x)
        delta_y = max(minimum_y - y, 0.0, y - maximum_y)
        clearances.append(math.hypot(delta_x, delta_y))
    return min(clearances)


def _neighbor_indices(index, width, height, include_diagonals):
    row, column = divmod(index, width)
    offsets = (
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1), (0, 1),
        (1, -1), (1, 0), (1, 1),
    ) if include_diagonals else (
        (-1, 0), (0, -1), (0, 1), (1, 0),
    )
    for row_delta, column_delta in offsets:
        next_row = row + row_delta
        next_column = column + column_delta
        if 0 <= next_row < height and 0 <= next_column < width:
            yield next_row * width + next_column


def _chebyshev_distances_to_non_free(width, height, pixels):
    distances = [-1] * (width * height)
    frontier = deque()
    for index, pixel in enumerate(pixels):
        if pixel != 254:
            distances[index] = 0
            frontier.append(index)

    while frontier:
        index = frontier.popleft()
        for next_index in _neighbor_indices(
            index, width, height, include_diagonals=True
        ):
            if distances[next_index] == -1:
                distances[next_index] = distances[index] + 1
                frontier.append(next_index)
    return distances


def _reachable_with_robot_clearance(
    width, height, pixels, resolution, robot_radius, start_index
):
    clearance_cells = _chebyshev_distances_to_non_free(
        width, height, pixels
    )
    traversable = {
        index
        for index, pixel in enumerate(pixels)
        if pixel == 254
        and (
            clearance_cells[index] * resolution - resolution / 2.0
            >= robot_radius
        )
    }
    if start_index not in traversable:
        return set()

    reachable = {start_index}
    frontier = deque((start_index,))
    while frontier:
        index = frontier.popleft()
        for next_index in _neighbor_indices(
            index, width, height, include_diagonals=False
        ):
            if next_index in traversable and next_index not in reachable:
                reachable.add(next_index)
                frontier.append(next_index)
    return reachable


def _non_free_cells(width, pixels):
    return [
        divmod(index, width)
        for index, pixel in enumerate(pixels)
        if pixel != 254
    ]


def test_repository_defaults_use_expected_patrol_poses():
    point_config = yaml.safe_load(
        (PACKAGE_ROOT / 'config/inspection_points.yaml').read_text(
            encoding='utf-8'
        )
    )
    mission_config = yaml.safe_load(
        (PACKAGE_ROOT / 'config/mission_templates.yaml').read_text(
            encoding='utf-8'
        )
    )
    points = {item['id']: item for item in point_config['points']}
    default_ids = next(
        item['points']
        for item in mission_config['missions']
        if item['id'] == 'night_patrol'
    )
    assert default_ids == list(EXPECTED_POINT_POSES)
    for point_id, expected_pose in EXPECTED_POINT_POSES.items():
        pose = points[point_id]['pose']
        assert (pose['x'], pose['y'], pose['yaw']) == expected_pose
    blocked_pose = points['blocked_optional_outside']['pose']
    assert (blocked_pose['x'], blocked_pose['y']) == (100.0, 100.0)


def test_initial_pose_and_default_mission_points_have_safe_clearance():
    map_config = yaml.safe_load(
        (MAP_DIR / 'map.yaml').read_text(encoding='utf-8')
    )
    width, height, pixels = _read_pgm(MAP_DIR / map_config['image'])
    resolution = float(map_config['resolution'])
    origin_x, origin_y, _ = map_config['origin']
    non_free_cells = _non_free_cells(width, pixels)
    poses = {'initial_pose': INITIAL_POSE}
    poses.update(
        (point_id, pose[:2])
        for point_id, pose in EXPECTED_POINT_POSES.items()
    )

    for point_id, (x, y) in poses.items():
        column = math.floor((x - origin_x) / resolution)
        row_from_bottom = math.floor((y - origin_y) / resolution)
        row = height - 1 - row_from_bottom
        assert 0 <= column < width, (point_id, x, y)
        assert 0 <= row < height, (point_id, x, y)
        index = row * width + column
        assert pixels[index] == 254, (point_id, x, y)
        clearance = _world_clearance(
            x,
            y,
            non_free_cells,
            height,
            resolution,
            origin_x,
            origin_y,
        )
        assert clearance >= 0.5, (point_id, x, y, clearance)


def test_default_mission_points_are_reachable_with_robot_clearance():
    map_config = yaml.safe_load(
        (MAP_DIR / 'map.yaml').read_text(encoding='utf-8')
    )
    width, height, pixels = _read_pgm(MAP_DIR / map_config['image'])
    resolution = float(map_config['resolution'])
    origin_x, origin_y, _ = map_config['origin']

    def pose_index(x, y):
        column = math.floor((x - origin_x) / resolution)
        row_from_bottom = math.floor((y - origin_y) / resolution)
        row = height - 1 - row_from_bottom
        return row * width + column

    reachable = _reachable_with_robot_clearance(
        width,
        height,
        pixels,
        resolution,
        ROBOT_RADIUS_METERS,
        pose_index(*INITIAL_POSE),
    )

    for point_id, pose in EXPECTED_POINT_POSES.items():
        assert pose_index(*pose[:2]) in reachable, (point_id, pose[:2])
