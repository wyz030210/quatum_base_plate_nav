from glob import glob
from setuptools import find_packages, setup


package_name = "property_inspection"


setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name + "/config", glob("config/*.yaml")),
        ("share/" + package_name + "/behavior_trees", glob("behavior_trees/*.xml")),
        ("share/" + package_name + "/launch", glob("launch/*.launch.py")),
        ("share/" + package_name + "/rviz", glob("rviz/*.rviz")),
        ("share/" + package_name + "/worlds", glob("worlds/*.world")),
    ],
    install_requires=["setuptools", "PyYAML"],
    zip_safe=True,
    maintainer="wyz",
    maintainer_email="wyz@example.com",
    description="Minimal closed-loop property inspection missions for TurtleBot3 and Nav2.",
    license="Apache-2.0",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "mission_manager = property_inspection.mission_manager_node:main",
            "coverage_task_node = property_inspection.coverage_task_node:main",
            "coverage_cli = property_inspection.coverage_cli:main",
        ],
    },
)
