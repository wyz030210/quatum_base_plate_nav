"""Start one TurtleBot3 simulation with OpenNav coverage support."""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    inspection_share = get_package_share_directory("property_inspection")
    tb3_navigation_share = get_package_share_directory("turtlebot3_navigation2")

    use_sim_time = LaunchConfiguration("use_sim_time")
    gui = LaunchConfiguration("gui")
    pause = LaunchConfiguration("pause")
    rviz = LaunchConfiguration("rviz")
    world = LaunchConfiguration("world")
    map_file = LaunchConfiguration("map")
    nav2_params = LaunchConfiguration("params_file")
    coverage_params = LaunchConfiguration("coverage_params_file")
    spawn_x = LaunchConfiguration("spawn_x")
    spawn_y = LaunchConfiguration("spawn_y")
    spawn_yaw = LaunchConfiguration("spawn_yaw")

    # The included launch also declares an argument named ``rviz``.  Keep its
    # forced-false value scoped to the include so it cannot overwrite this
    # launch file's public ``rviz`` switch and suppress the coverage RViz node.
    simulation = GroupAction(
        scoped=True,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(
                        inspection_share, "launch", "inspection_sim.launch.py"
                    )
                ),
                launch_arguments={
                    "start_mission": "false",
                    "rviz": "false",
                    "gui": gui,
                    "pause": pause,
                    "use_sim_time": use_sim_time,
                    "world": world,
                    "map": map_file,
                    "params_file": nav2_params,
                    "spawn_x": spawn_x,
                    "spawn_y": spawn_y,
                    "spawn_yaw": spawn_yaw,
                }.items(),
            )
        ],
    )
    coverage_server = Node(
        package="opennav_coverage",
        executable="opennav_coverage",
        name="coverage_server",
        output="screen",
        parameters=[
            coverage_params,
            {"use_sim_time": ParameterValue(use_sim_time, value_type=bool)},
        ],
    )
    coverage_lifecycle = Node(
        package="nav2_lifecycle_manager",
        executable="lifecycle_manager",
        name="lifecycle_manager_coverage",
        output="screen",
        parameters=[
            {
                "use_sim_time": ParameterValue(use_sim_time, value_type=bool),
                "autostart": True,
                "node_names": ["coverage_server"],
            }
        ],
    )
    task_node = Node(
        package="property_inspection",
        executable="coverage_task_node",
        name="coverage_task_node",
        output="screen",
        parameters=[
            coverage_params,
            {"use_sim_time": ParameterValue(use_sim_time, value_type=bool)},
        ],
    )
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        condition=IfCondition(rviz),
        arguments=["-d", os.path.join(inspection_share, "rviz", "coverage.rviz")],
        parameters=[
            {"use_sim_time": ParameterValue(use_sim_time, value_type=bool)}
        ],
        output="screen",
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("gui", default_value="true"),
            DeclareLaunchArgument("pause", default_value="false"),
            DeclareLaunchArgument("rviz", default_value="true"),
            DeclareLaunchArgument("use_sim_time", default_value="true"),
            DeclareLaunchArgument(
                "world",
                default_value=os.path.join(
                    inspection_share, "worlds", "room3.world"
                ),
            ),
            DeclareLaunchArgument(
                "map",
                default_value=os.path.join(tb3_navigation_share, "map", "map.yaml"),
            ),
            DeclareLaunchArgument(
                "params_file",
                default_value=os.path.join(
                    inspection_share, "config", "nav2_params_inspection.yaml"
                ),
            ),
            DeclareLaunchArgument(
                "coverage_params_file",
                default_value=os.path.join(
                    inspection_share, "config", "coverage_params.yaml"
                ),
            ),
            DeclareLaunchArgument("spawn_x", default_value="-10.5"),
            DeclareLaunchArgument("spawn_y", default_value="-1.0"),
            DeclareLaunchArgument("spawn_yaw", default_value="0.0"),
            simulation,
            coverage_server,
            coverage_lifecycle,
            task_node,
            rviz_node,
        ]
    )
