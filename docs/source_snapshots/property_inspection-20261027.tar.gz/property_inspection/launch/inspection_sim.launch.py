"""Start TurtleBot3 World, Nav2, RViz, and one inspection mission."""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from nav2_common.launch import RewrittenYaml


def generate_launch_description():
    inspection_share = get_package_share_directory("property_inspection")
    gazebo_share = get_package_share_directory("gazebo_ros")
    nav2_share = get_package_share_directory("nav2_bringup")
    tb3_gazebo_share = get_package_share_directory("turtlebot3_gazebo")
    tb3_navigation_share = get_package_share_directory(
        "turtlebot3_navigation2"
    )

    mission_id = LaunchConfiguration("mission_id")
    start_mission = LaunchConfiguration("start_mission")
    gui = LaunchConfiguration("gui")
    pause = LaunchConfiguration("pause")
    rviz = LaunchConfiguration("rviz")
    use_sim_time = LaunchConfiguration("use_sim_time")
    report_dir = LaunchConfiguration("report_dir")
    navigation_timeout = LaunchConfiguration("navigation_timeout_sec")
    params_file = LaunchConfiguration("params_file")
    map_file = LaunchConfiguration("map")
    world = LaunchConfiguration("world")
    spawn_x = LaunchConfiguration("spawn_x")
    spawn_y = LaunchConfiguration("spawn_y")
    spawn_yaw = LaunchConfiguration("spawn_yaw")
    points_file = LaunchConfiguration("points_file")
    missions_file = LaunchConfiguration("missions_file")
    initial_pose_x = LaunchConfiguration("initial_pose_x")
    initial_pose_y = LaunchConfiguration("initial_pose_y")
    initial_pose_yaw = LaunchConfiguration("initial_pose_yaw")

    behavior_tree_path = os.path.join(
        inspection_share, "behavior_trees", "inspection_nav_to_pose.xml"
    )
    rewritten_params = RewrittenYaml(
        source_file=params_file,
        root_key="",
        param_rewrites={
            "use_sim_time": use_sim_time,
            "default_nav_to_pose_bt_xml": behavior_tree_path,
        },
        convert_types=True,
    )

    gzserver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_share, "launch", "gzserver.launch.py")
        ),
        launch_arguments={
            "world": world,
            "pause": pause,
        }.items(),
    )
    gzclient = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_share, "launch", "gzclient.launch.py")
        ),
        condition=IfCondition(gui),
    )
    robot_state_publisher = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                tb3_gazebo_share,
                "launch",
                "robot_state_publisher.launch.py",
            )
        ),
        launch_arguments={"use_sim_time": use_sim_time}.items(),
    )
    spawn_robot = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=[
            "-entity",
            "burger",
            "-file",
            os.path.join(
                tb3_gazebo_share,
                "models",
                "turtlebot3_burger",
                "model.sdf",
            ),
            "-x",
            spawn_x,
            "-y",
            spawn_y,
            "-z",
            "0.01",
            "-Y",
            spawn_yaw,
        ],
        output="screen",
    )
    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_share, "launch", "bringup_launch.py")
        ),
        launch_arguments={
            "map": map_file,
            "params_file": rewritten_params,
            "use_sim_time": use_sim_time,
            "autostart": "true",
            "slam": "False",
            "use_composition": "True",
        }.items(),
    )
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        condition=IfCondition(rviz),
        arguments=[
            "-d",
            os.path.join(
                tb3_navigation_share, "rviz", "tb3_navigation2.rviz"
            ),
        ],
        parameters=[
            {
                "use_sim_time": ParameterValue(
                    use_sim_time, value_type=bool
                )
            }
        ],
        output="screen",
    )
    mission_node = Node(
        package="property_inspection",
        executable="mission_manager",
        name="mission_manager",
        output="screen",
        condition=IfCondition(start_mission),
        parameters=[
            {
                "use_sim_time": ParameterValue(use_sim_time, value_type=bool),
                "mission_id": mission_id,
                "report_dir": report_dir,
                "navigation_timeout_sec": ParameterValue(
                    navigation_timeout, value_type=float
                ),
                "initial_pose_x": ParameterValue(
                    initial_pose_x, value_type=float
                ),
                "initial_pose_y": ParameterValue(
                    initial_pose_y, value_type=float
                ),
                "initial_pose_yaw": ParameterValue(
                    initial_pose_yaw, value_type=float
                ),
                "points_file": points_file,
                "missions_file": missions_file,
            }
        ],
    )

    return LaunchDescription(
        [
            SetEnvironmentVariable("TURTLEBOT3_MODEL", "burger"),
            DeclareLaunchArgument(
                "mission_id",
                default_value="night_patrol",
                description="Mission template ID to run once",
            ),
            DeclareLaunchArgument(
                "start_mission",
                default_value="false",
                description="Set to true to start inspection mission automatically",
            ),
            DeclareLaunchArgument(
                "gui",
                default_value="true",
                description="Start the Gazebo client",
            ),
            DeclareLaunchArgument(
                "pause",
                default_value="false",
                description="Start Gazebo paused",
            ),
            DeclareLaunchArgument(
                "rviz", default_value="true", description="Start RViz"
            ),
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="true",
                description="Use the Gazebo clock",
            ),
            DeclareLaunchArgument(
                "report_dir",
                default_value="~/.ros/property_inspection/reports",
                description="Directory for mission reports",
            ),
            DeclareLaunchArgument(
                "navigation_timeout_sec",
                default_value="120.0",
                description="Per-point navigation timeout in seconds",
            ),
            DeclareLaunchArgument(
                "params_file",
                default_value=os.path.join(
                    inspection_share,
                    "config",
                    "nav2_params_inspection.yaml",
                ),
                description="Complete Nav2 parameter file",
            ),
            DeclareLaunchArgument(
                "map",
                default_value=os.path.join(
                    tb3_navigation_share, "map", "map.yaml"
                ),
                description="Static map YAML",
            ),
            DeclareLaunchArgument(
                "world",
                default_value=os.path.join(
                    inspection_share, "worlds", "room3.world"
                ),
                description="Gazebo world file",
            ),
            DeclareLaunchArgument(
                "spawn_x",
                default_value="-10.5",
                description="Robot spawn X coordinate in Gazebo",
            ),
            DeclareLaunchArgument(
                "spawn_y",
                default_value="-1.0",
                description="Robot spawn Y coordinate in Gazebo",
            ),
            DeclareLaunchArgument(
                "spawn_yaw",
                default_value="0.0",
                description="Robot spawn yaw in Gazebo",
            ),
            DeclareLaunchArgument(
                "initial_pose_x",
                default_value="3.0",
                description="Initial Nav2 map X coordinate",
            ),
            DeclareLaunchArgument(
                "initial_pose_y",
                default_value="-1.5",
                description="Initial Nav2 map Y coordinate",
            ),
            DeclareLaunchArgument(
                "initial_pose_yaw",
                default_value="0.0",
                description="Initial Nav2 map yaw",
            ),
            DeclareLaunchArgument(
                "points_file",
                default_value="",
                description="Custom inspection points YAML (empty = use default)",
            ),
            DeclareLaunchArgument(
                "missions_file",
                default_value="",
                description="Custom mission templates YAML (empty = use default)",
            ),
            gzserver,
            gzclient,
            robot_state_publisher,
            spawn_robot,
            nav2_bringup,
            rviz_node,
            mission_node,
        ]
    )
